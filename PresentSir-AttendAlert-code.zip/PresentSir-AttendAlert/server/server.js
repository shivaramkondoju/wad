import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { router as apiRouter } from './routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5001;

// Middlewares
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static uploads directory
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOAD_DIR));

// Health Check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'PresentSir / AttendAlert API',
    timestamp: new Date().toISOString()
  });
});

// Direct ZIP download endpoint
app.get('/download-zip', (req, res) => {
  const zipPath = path.join(__dirname, '..', 'PresentSir-AttendAlert.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'PresentSir-AttendAlert.zip');
  } else {
    res.status(404).send('ZIP file not found');
  }
});

// Mount API routes
app.use('/api', apiRouter);

// Serve Frontend Production Build if present
const CLIENT_DIST = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST));
  // Express 5 compatible SPA fallback
  app.use((req, res, next) => {
    if (req.method !== 'GET') return next();
    if (req.path.startsWith('/api') || req.path.startsWith('/uploads') || req.path.startsWith('/health')) {
      return next();
    }
    res.sendFile(path.join(CLIENT_DIST, 'index.html'));
  });
}

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).json({
    success: false,
    error: err.message || 'Internal Server Error'
  });
});

app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`PresentSir / AttendAlert Server running on port ${PORT}`);
  console.log(`Web App & API: http://localhost:${PORT}`);
  console.log(`API Health:    http://localhost:${PORT}/health`);
  console.log(`=======================================================`);
});
