/**
 * Realistic seed dataset for PresentSir / AttendAlert
 * 30 Engineering students, 5 subjects, 4 weeks of sessions (16 sessions per subject)
 */

export const INITIAL_SUBJECTS = [
  {
    id: 'CS501',
    code: 'CS501',
    name: 'Data Structures & Algorithms',
    shortName: 'DSA',
    credits: 4,
    facultyId: 'FAC001',
    facultyName: 'Prof. Dr. Arvind Menon',
    room: 'LH-302',
    color: 'indigo'
  },
  {
    id: 'CS502',
    code: 'CS502',
    name: 'Database Management Systems',
    shortName: 'DBMS',
    credits: 4,
    facultyId: 'FAC002',
    facultyName: 'Prof. Sunita Rao',
    room: 'LH-304',
    color: 'emerald'
  },
  {
    id: 'CS503',
    code: 'CS503',
    name: 'Operating Systems',
    shortName: 'OS',
    credits: 3,
    facultyId: 'FAC003',
    facultyName: 'Prof. Vikram Seth',
    room: 'LH-201',
    color: 'amber'
  },
  {
    id: 'CS504',
    code: 'CS504',
    name: 'Computer Networks',
    shortName: 'CN',
    credits: 3,
    facultyId: 'FAC004',
    facultyName: 'Prof. Priya Nair',
    room: 'LH-105',
    color: 'cyan'
  },
  {
    id: 'CS505',
    code: 'CS505',
    name: 'Theory of Computation',
    shortName: 'TOC',
    credits: 3,
    facultyId: 'FAC005',
    facultyName: 'Prof. Rajesh Iyer',
    room: 'LH-208',
    color: 'rose'
  }
];

export const INITIAL_STUDENTS = [
  {
    id: 'STU001',
    rollNo: '21CS042',
    name: 'Rahul Verma',
    email: 'rahul.verma@college.edu',
    parentEmail: 'suresh.verma@parentmail.com',
    parentPhone: '+91 98765 43210',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 61.25 // Targeted critical demo student
  },
  {
    id: 'STU002',
    rollNo: '21CS002',
    name: 'Ananya Sharma',
    email: 'ananya.sharma@college.edu',
    parentEmail: 'ashok.sharma@parentmail.com',
    parentPhone: '+91 98451 12345',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 92.5
  },
  {
    id: 'STU003',
    rollNo: '21CS003',
    name: 'Rohan Gupta',
    email: 'rohan.gupta@college.edu',
    parentEmail: 'manish.gupta@parentmail.com',
    parentPhone: '+91 98111 22334',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 58.75 // Critical
  },
  {
    id: 'STU004',
    rollNo: '21CS004',
    name: 'Kavita Patel',
    email: 'kavita.patel@college.edu',
    parentEmail: 'dinesh.patel@parentmail.com',
    parentPhone: '+91 97234 56789',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 86.25
  },
  {
    id: 'STU005',
    rollNo: '21CS005',
    name: 'Aditya Kulkarni',
    email: 'aditya.k@college.edu',
    parentEmail: 'vijay.kulkarni@parentmail.com',
    parentPhone: '+91 99201 34567',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 63.75 // Critical
  },
  {
    id: 'STU006',
    rollNo: '21CS006',
    name: 'Sneha Deshmukh',
    email: 'sneha.d@college.edu',
    parentEmail: 'pramod.deshmukh@parentmail.com',
    parentPhone: '+91 98333 44556',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 71.25 // Warning
  },
  {
    id: 'STU007',
    rollNo: '21CS007',
    name: 'Vikramaditya Roy',
    email: 'vikram.roy@college.edu',
    parentEmail: 'samir.roy@parentmail.com',
    parentPhone: '+91 94330 98765',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 55.0 // Critical
  },
  {
    id: 'STU008',
    rollNo: '21CS008',
    name: 'Pooja Hegde',
    email: 'pooja.h@college.edu',
    parentEmail: 'shankar.hegde@parentmail.com',
    parentPhone: '+91 98860 11223',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 78.75
  },
  {
    id: 'STU009',
    rollNo: '21CS009',
    name: 'Arjun Nambiar',
    email: 'arjun.n@college.edu',
    parentEmail: 'gopinath.nambiar@parentmail.com',
    parentPhone: '+91 94471 23456',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 68.75 // Warning
  },
  {
    id: 'STU010',
    rollNo: '21CS010',
    name: 'Meera Chawla',
    email: 'meera.c@college.edu',
    parentEmail: 'harish.chawla@parentmail.com',
    parentPhone: '+91 98102 34567',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 95.0
  },
  {
    id: 'STU011',
    rollNo: '21CS011',
    name: 'Tanmay Joshi',
    email: 'tanmay.j@college.edu',
    parentEmail: 'shrikant.joshi@parentmail.com',
    parentPhone: '+91 98220 54321',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 60.0 // Critical (5th critical student)
  },
  {
    id: 'STU012',
    rollNo: '21CS012',
    name: 'Isha Reddy',
    email: 'isha.reddy@college.edu',
    parentEmail: 'venkat.reddy@parentmail.com',
    parentPhone: '+91 98490 65432',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 73.75 // Warning
  },
  {
    id: 'STU013',
    rollNo: '21CS013',
    name: 'Karthik Subbaraj',
    email: 'karthik.s@college.edu',
    parentEmail: 'muthu.subbaraj@parentmail.com',
    parentPhone: '+91 94440 76543',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 67.5 // Warning
  },
  {
    id: 'STU014',
    rollNo: '21CS014',
    name: 'Divya Singhania',
    email: 'divya.s@college.edu',
    parentEmail: 'alok.singhania@parentmail.com',
    parentPhone: '+91 98300 87654',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 88.75
  },
  {
    id: 'STU015',
    rollNo: '21CS015',
    name: 'Siddharth Sen',
    email: 'sid.sen@college.edu',
    parentEmail: 'debashis.sen@parentmail.com',
    parentPhone: '+91 98311 98760',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 72.5 // Warning
  },
  {
    id: 'STU016',
    rollNo: '21CS016',
    name: 'Riya Malhotra',
    email: 'riya.m@college.edu',
    parentEmail: 'sunil.malhotra@parentmail.com',
    parentPhone: '+91 98180 12345',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 82.5
  },
  {
    id: 'STU017',
    rollNo: '21CS017',
    name: 'Nikhil Saxena',
    email: 'nikhil.saxena@college.edu',
    parentEmail: 'rajiv.saxena@parentmail.com',
    parentPhone: '+91 97170 23456',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 70.0 // Warning
  },
  {
    id: 'STU018',
    rollNo: '21CS018',
    name: 'Priyanka Ghosh',
    email: 'priyanka.g@college.edu',
    parentEmail: 'aniruddha.ghosh@parentmail.com',
    parentPhone: '+91 98302 34567',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 74.5 // Warning near boundary
  },
  {
    id: 'STU019',
    rollNo: '21CS019',
    name: 'Varun Nair',
    email: 'varun.nair@college.edu',
    parentEmail: 'sudheesh.nair@parentmail.com',
    parentPhone: '+91 94470 34567',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 81.25
  },
  {
    id: 'STU020',
    rollNo: '21CS020',
    name: 'Shreya Tiwari',
    email: 'shreya.t@college.edu',
    parentEmail: 'omkar.tiwari@parentmail.com',
    parentPhone: '+91 94150 45678',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 90.0
  },
  {
    id: 'STU021',
    rollNo: '21CS021',
    name: 'Manish Rawat',
    email: 'manish.rawat@college.edu',
    parentEmail: 'birendra.rawat@parentmail.com',
    parentPhone: '+91 98119 56789',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 76.25
  },
  {
    id: 'STU022',
    rollNo: '21CS022',
    name: 'Tara Alva',
    email: 'tara.alva@college.edu',
    parentEmail: 'jayaram.alva@parentmail.com',
    parentPhone: '+91 98800 67890',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 85.0
  },
  {
    id: 'STU023',
    rollNo: '21CS023',
    name: 'Akash Banerjee',
    email: 'akash.b@college.edu',
    parentEmail: 'soumitra.banerjee@parentmail.com',
    parentPhone: '+91 98319 78901',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 80.0
  },
  {
    id: 'STU024',
    rollNo: '21CS024',
    name: 'Deepika Rao',
    email: 'deepika.rao@college.edu',
    parentEmail: 'raghavendra.rao@parentmail.com',
    parentPhone: '+91 98450 89012',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 93.75
  },
  {
    id: 'STU025',
    rollNo: '21CS025',
    name: 'Pranav Bhat',
    email: 'pranav.bhat@college.edu',
    parentEmail: 'krishna.bhat@parentmail.com',
    parentPhone: '+91 98862 90123',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 77.5
  },
  {
    id: 'STU026',
    rollNo: '21CS026',
    name: 'Anu Mathur',
    email: 'anu.mathur@college.edu',
    parentEmail: 'pradeep.mathur@parentmail.com',
    parentPhone: '+91 98290 01234',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 87.5
  },
  {
    id: 'STU027',
    rollNo: '21CS027',
    name: 'Gaurav Agarwal',
    email: 'gaurav.a@college.edu',
    parentEmail: 'anil.agarwal@parentmail.com',
    parentPhone: '+91 98370 12345',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 83.75
  },
  {
    id: 'STU028',
    rollNo: '21CS028',
    name: 'Harini Sundaram',
    email: 'harini.s@college.edu',
    parentEmail: 'sundaram.k@parentmail.com',
    parentPhone: '+91 94441 23456',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 96.25
  },
  {
    id: 'STU029',
    rollNo: '21CS029',
    name: 'Chirag Parekh',
    email: 'chirag.p@college.edu',
    parentEmail: 'bharat.parekh@parentmail.com',
    parentPhone: '+91 98250 34567',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 78.0
  },
  {
    id: 'STU030',
    rollNo: '21CS030',
    name: 'Bhavna Chauhan',
    email: 'bhavna.c@college.edu',
    parentEmail: 'karan.chauhan@parentmail.com',
    parentPhone: '+91 98990 45678',
    semester: 5,
    section: 'A',
    department: 'Computer Science & Engineering',
    mentorName: 'Prof. Dr. Arvind Menon',
    targetOverall: 82.0
  }
];

export const SUBJECT_TOPICS = {
  CS501: [
    'Asymptotic Notation & Recurrence Relations',
    'Divide and Conquer: MergeSort & QuickSort',
    'Heaps and Priority Queues',
    'Binary Search Trees: Insertion & Deletion',
    'AVL Trees & Self-Balancing Rotations',
    'B-Trees and B+ Trees for File Systems',
    'Hashing Techniques & Collision Resolution',
    'Disjoint Set Union (DSU) & Union-Find',
    'Graph Representation & BFS/DFS Traversals',
    'Dijkstra Shortest Path Algorithm',
    'Bellman-Ford & Negative Weight Cycles',
    'Minimum Spanning Trees: Prim and Kruskal',
    'Dynamic Programming: 0/1 Knapsack Problem',
    'Longest Common Subsequence (LCS)',
    'Greedy Algorithms & Activity Selection',
    'NP-Completeness & P vs NP Foundations'
  ],
  CS502: [
    'Relational Data Model & ER Diagrams',
    'Relational Algebra & Tuple Calculus',
    'SQL DDL & Complex Joins',
    'Subqueries, Views and Triggers',
    'Functional Dependencies & Armstrong Axioms',
    'Normal Forms: 1NF, 2NF, 3NF',
    'Boyce-Codd Normal Form (BCNF) & 4NF',
    'Storage Architecture & RAID Configurations',
    'Indexing: Dense, Sparse and B+ Trees',
    'Query Processing & Cost Estimation',
    'Query Optimization Engine',
    'ACID Properties & Transaction States',
    'Concurrency Control: 2PL & Strict 2PL',
    'Timestamp-Based Protocol & Validation',
    'Deadlock Detection & Wait-For Graphs',
    'Database Recovery: Write-Ahead Logging (WAL)'
  ],
  CS503: [
    'OS Architecture & System Call Interface',
    'Process Control Block (PCB) & Context Switching',
    'CPU Scheduling: FCFS, SJF, Round Robin',
    'Multi-Level Feedback Queue Scheduling',
    'Inter-Process Communication (IPC) Pipes & Queues',
    'Classical Sync: Dining Philosophers & Semaphores',
    'Monitors & Condition Variables',
    'Deadlock Characterization & Prevention',
    'Banker\'s Algorithm for Deadlock Avoidance',
    'Memory Management & Swapping',
    'Paging Architecture & Translation Lookaside Buffer (TLB)',
    'Page Replacement Algorithms: FIFO, LRU, Optimal',
    'Virtual Memory & Demand Paging Thrashing',
    'File System Interface & Directory Structure',
    'Disk Arm Scheduling: SCAN, C-SCAN, LOOK',
    'I/O Subsystem, Direct Memory Access (DMA)'
  ],
  CS504: [
    'OSI Reference Model vs TCP/IP Stack',
    'Physical Layer & Transmission Impairments',
    'Data Link Layer: Framing & CRC Checksums',
    'Sliding Window Protocols: Go-Back-N & Selective Repeat',
    'Medium Access Control: CSMA/CD and CSMA/CA',
    'Ethernet Standards & Switching Fabric',
    'IPv4 Addressing, Subnetting & CIDR',
    'Routing Algorithms: Distance Vector (RIP)',
    'Link State Routing: Dijkstra & OSPF',
    'Border Gateway Protocol (BGP) Routing',
    'Address Resolution Protocol (ARP) & ICMP',
    'User Datagram Protocol (UDP) Architecture',
    'Transmission Control Protocol (TCP) 3-Way Handshake',
    'TCP Flow Control & AIMD Congestion Control',
    'Domain Name System (DNS) Resolution Chain',
    'Hypertext Transfer Protocol (HTTP/2 & HTTP/3)'
  ],
  CS505: [
    'Deterministic Finite Automata (DFA) Construction',
    'Non-Deterministic Finite Automata (NFA) to DFA Conversion',
    'Regular Expressions & Equivalence with FA',
    'Pumping Lemma for Regular Languages',
    'Myhill-Nerode Theorem & DFA State Minimization',
    'Context-Free Grammars (CFG) & Derivation Trees',
    'Ambiguity in Grammars & Inherent Ambiguity',
    'Chomsky Normal Form (CNF) Conversion',
    'Pushdown Automata (PDA): Transition & Stack Operations',
    'Equivalence of PDA and Context-Free Languages',
    'Pumping Lemma for Context-Free Languages',
    'Turing Machine (TM) Architecture & Tape Operations',
    'Techniques for Turing Machine Construction',
    'Variants of TM: Multi-tape, Non-deterministic',
    'Church-Turing Thesis & Decidability',
    'Halting Problem & Reducibility'
  ]
};

/**
 * Generates initial 4-week sessions and logs
 */
export function generateSeedData() {
  const students = INITIAL_STUDENTS.map(s => ({
    id: s.id,
    rollNo: s.rollNo,
    name: s.name,
    email: s.email,
    parentEmail: s.parentEmail,
    parentPhone: s.parentPhone,
    semester: s.semester,
    section: s.section,
    department: s.department,
    mentorName: s.mentorName
  }));

  const subjects = INITIAL_SUBJECTS;
  const sessions = [];
  const attendanceRecords = [];
  const midtermMarks = [];

  // Generate 16 sessions for each subject spread over 4 weeks (Oct 20, 2026 - Nov 16, 2026)
  // 4 sessions per week for each subject
  const startDate = new Date('2026-10-19T09:00:00');

  subjects.forEach((sub, subIdx) => {
    const topics = SUBJECT_TOPICS[sub.id];

    for (let sessionIdx = 0; sessionIdx < 16; sessionIdx++) {
      const sessionId = `SES_${sub.id}_${String(sessionIdx + 1).padStart(2, '0')}`;
      const dayOffset = Math.floor(sessionIdx / 4) * 7 + (sessionIdx % 4);
      const sessionDate = new Date(startDate);
      sessionDate.setDate(startDate.getDate() + dayOffset);
      const dateStr = sessionDate.toISOString().split('T')[0];

      const timeSlots = [
        '09:00 - 10:00 AM',
        '10:15 - 11:15 AM',
        '11:30 - 12:30 PM',
        '01:30 - 02:30 PM',
        '02:45 - 03:45 PM'
      ];
      const slot = timeSlots[subIdx % timeSlots.length];

      let presentCount = 0;
      let absentCount = 0;
      let lateCount = 0;

      students.forEach((stu, stuIdx) => {
        let status = 'PRESENT';

        // Precise edge case for Rahul Verma (STU001) in CS501 (Data Structures):
        // Needs exactly 10 attended out of 16 classes = 62.5% (~62%), needing 8 consecutive classes!
        if (stu.id === 'STU001' && sub.id === 'CS501') {
          // Attend classes 0, 1, 3, 4, 6, 8, 9, 11, 13, 15 -> exactly 10 classes
          const rahulAttendedIndices = [0, 1, 3, 4, 6, 8, 9, 11, 13, 15];
          status = rahulAttendedIndices.includes(sessionIdx) ? 'PRESENT' : 'ABSENT';
        } else {
          // Use target overall percentage to guide attendance probability
          const target = INITIAL_STUDENTS[stuIdx].targetOverall;
          // Introduce slight deterministic variation per subject
          const variation = ((subIdx * 7 + sessionIdx * 13) % 15) - 7;
          const subjectTarget = Math.max(45, Math.min(98, target + variation));

          // Deterministic pseudo-random threshold
          const pseudoHash = ((stuIdx * 37 + subIdx * 19 + sessionIdx * 23) % 100);
          if (pseudoHash < subjectTarget - 5) {
            status = 'PRESENT';
          } else if (pseudoHash < subjectTarget) {
            status = 'LATE'; // counts as present or recorded as late
          } else {
            status = 'ABSENT';
          }
        }

        if (status === 'PRESENT') presentCount++;
        else if (status === 'LATE') {
          lateCount++;
          presentCount++; // Late is counted with warning in records
        } else absentCount++;

        attendanceRecords.push({
          id: `REC_${sessionId}_${stu.id}`,
          sessionId,
          subjectId: sub.id,
          studentId: stu.id,
          status,
          timestamp: `${dateStr}T${slot.slice(0, 5)}:00Z`
        });
      });

      sessions.push({
        id: sessionId,
        subjectId: sub.id,
        facultyId: sub.facultyId,
        facultyName: sub.facultyName,
        date: dateStr,
        slot,
        topic: topics[sessionIdx] || `Unit ${Math.floor(sessionIdx / 3) + 1} Lecture ${sessionIdx + 1}`,
        totalStudents: students.length,
        presentCount,
        absentCount,
        lateCount,
        createdAt: `${dateStr}T12:00:00Z`
      });
    }
  });

  // Generate Midterm Marks (out of 50) and Assignment marks (out of 20)
  // Strong correlation with student attendance
  students.forEach((stu, stuIdx) => {
    const target = INITIAL_STUDENTS[stuIdx].targetOverall;
    subjects.forEach((sub, subIdx) => {
      // Calculate actual attendance for this student in this subject
      const studentRecs = attendanceRecords.filter(r => r.studentId === stu.id && r.subjectId === sub.id);
      const attended = studentRecs.filter(r => r.status === 'PRESENT' || r.status === 'LATE').length;
      const total = studentRecs.length;
      const attRatio = total > 0 ? (attended / total) : 0.75;

      // Realistic academic correlation formula with slight realistic noise
      // Midterm (out of 50): base score = attRatio * 42 + noise
      const noise = ((stuIdx * 11 + subIdx * 17) % 7) - 3;
      const midtermScore = Math.max(12, Math.min(49, Math.round(attRatio * 44 + noise)));
      const assignmentScore = Math.max(8, Math.min(20, Math.round(attRatio * 18 + ((noise + 3) % 3))));

      midtermMarks.push({
        id: `MRK_${stu.id}_${sub.id}`,
        studentId: stu.id,
        studentName: stu.name,
        subjectId: sub.id,
        subjectName: sub.name,
        attendancePercentage: Math.round(attRatio * 100),
        midtermMarks: midtermScore,
        maxMidtermMarks: 50,
        assignmentMarks: assignmentScore,
        maxAssignmentMarks: 20,
        totalPercentage: Math.round(((midtermScore + assignmentScore) / 70) * 100)
      });
    });
  });

  // Seed Medical Exemption Requests (stretch feature)
  const medicalExemptions = [
    {
      id: 'MED_001',
      studentId: 'STU006',
      studentName: 'Sneha Deshmukh',
      rollNo: '21CS006',
      subjectIds: ['CS501', 'CS502'],
      startDate: '2026-10-27',
      endDate: '2026-10-29',
      sessionsAffectedCount: 4,
      reason: 'Acute Gastroenteritis & Dehydration under Hospital Care',
      doctorName: 'Dr. Ramesh Kulkarni, MD',
      hospital: 'City Care Multispeciality Hospital',
      certificateUrl: '/uploads/medical_STU006_sneha.pdf',
      status: 'PENDING', // Ready for judge/mentor to approve!
      appliedAt: '2026-10-30T10:15:00Z',
      reviewedBy: null,
      reviewedAt: null,
      remarks: 'Student has attached discharge summary and doctor prescription.'
    },
    {
      id: 'MED_002',
      studentId: 'STU015',
      studentName: 'Siddharth Sen',
      rollNo: '21CS015',
      subjectIds: ['CS503'],
      startDate: '2026-11-03',
      endDate: '2026-11-05',
      sessionsAffectedCount: 2,
      reason: 'Fractured Right Metacarpal with Cast Immobilization',
      doctorName: 'Dr. Ananya Roy, MS Ortho',
      hospital: 'Apex Bone & Joint Clinic',
      certificateUrl: '/uploads/medical_STU015_siddharth.pdf',
      status: 'APPROVED',
      appliedAt: '2026-11-06T09:30:00Z',
      reviewedBy: 'Prof. Dr. Arvind Menon',
      reviewedAt: '2026-11-07T14:20:00Z',
      remarks: 'Verified with hospital reception. Exemption granted for 2 lab sessions.'
    }
  ];

  // Seed Initial Mentoring Interventions (Mentor Hub)
  const mentoringInterventions = [
    {
      id: 'MNT_001',
      studentId: 'STU003',
      studentName: 'Rohan Gupta',
      rollNo: '21CS003',
      mentorName: 'Prof. Dr. Arvind Menon',
      date: '2026-11-10T11:00:00Z',
      riskTierAtTime: 'CRITICAL',
      currentPercentage: 58.75,
      subjectId: 'CS503',
      subjectName: 'Operating Systems',
      classesNeeded: 11,
      interventionType: 'One-on-One Counseling',
      counselingNotes: 'Student stated long commute from distant suburb causes morning class misses. Advised on early college bus schedule.',
      actionPlan: 'Student committed to attending next 12 consecutive lectures. Assigned peer buddy (Ananya Sharma) for lecture note sharing.',
      status: 'In Progress',
      nextFollowUpDate: '2026-11-24'
    },
    {
      id: 'MNT_002',
      studentId: 'STU007',
      studentName: 'Vikramaditya Roy',
      rollNo: '21CS007',
      mentorName: 'Prof. Dr. Arvind Menon',
      date: '2026-11-08T15:30:00Z',
      riskTierAtTime: 'CRITICAL',
      currentPercentage: 55.0,
      subjectId: 'CS505',
      subjectName: 'Theory of Computation',
      classesNeeded: 13,
      interventionType: 'Parent Call',
      counselingNotes: 'Telephonic counseling conducted with father (Mr. Samir Roy). Informed family regarding imminent detention risk in upcoming semester exams.',
      actionPlan: 'Parent will monitor daily morning departures. Weekly attendance email check-in activated.',
      status: 'Open',
      nextFollowUpDate: '2026-11-22'
    }
  ];

  // Seed Initial Simulated Notification Outbox Logs
  const alertLogs = [
    {
      id: 'ALT_001',
      studentId: 'STU003',
      studentName: 'Rohan Gupta',
      rollNo: '21CS003',
      recipientType: 'BOTH',
      studentEmail: 'rohan.gupta@college.edu',
      parentEmail: 'manish.gupta@parentmail.com',
      riskTier: 'CRITICAL',
      attendancePercent: 58.75,
      consecutiveClassesNeeded: 11,
      subject: 'URGENT: Academic Detention Warning Notice - Attendance Shortage (<65%)',
      bodySnippet: 'Cumulative attendance has fallen to 58.8% in Operating Systems. Minimum 75% required by university statute...',
      sentAt: '2026-11-10T11:05:00Z',
      triggeredBy: 'Automated Threshold Daemon & Mentor Confirmation',
      status: 'SIMULATED'
    }
  ];

  return {
    students,
    subjects,
    sessions,
    attendanceRecords,
    midtermMarks,
    medicalExemptions,
    mentoringInterventions,
    alertLogs
  };
}
