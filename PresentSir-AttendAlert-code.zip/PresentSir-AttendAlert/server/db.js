import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateSeedData } from './seedData.js';
import { classifyRisk, calculateClassesNeeded, calculateBunkAllowance } from './calc.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'database.json');

class Database {
  constructor() {
    this.data = null;
    this.cache = {
      computedStudents: null,
      studentsMap: null,
      overview: null,
      correlation: null
    };
    this.init();
  }

  init() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_PATH)) {
      try {
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        this.data = JSON.parse(raw);
        console.log('Database loaded successfully from file.');
        this.rebuildCache();
        return;
      } catch (err) {
        console.error('Error loading database file, re-seeding...', err);
      }
    }

    this.reset();
  }

  invalidateCache() {
    this.cache.computedStudents = null;
    this.cache.studentsMap = null;
    this.cache.overview = null;
    this.cache.correlation = null;
  }

  rebuildCache() {
    if (!this.data) return;

    // Fast indexed lookups
    const recordsByStudentSubject = {};
    for (let i = 0; i < this.data.attendanceRecords.length; i++) {
      const r = this.data.attendanceRecords[i];
      if (!recordsByStudentSubject[r.studentId]) {
        recordsByStudentSubject[r.studentId] = {};
      }
      if (!recordsByStudentSubject[r.studentId][r.subjectId]) {
        recordsByStudentSubject[r.studentId][r.subjectId] = [];
      }
      recordsByStudentSubject[r.studentId][r.subjectId].push(r);
    }

    const interventionsByStudent = {};
    for (let i = 0; i < this.data.mentoringInterventions.length; i++) {
      const m = this.data.mentoringInterventions[i];
      if (!interventionsByStudent[m.studentId]) interventionsByStudent[m.studentId] = [];
      interventionsByStudent[m.studentId].push(m);
    }

    const medicalByStudent = {};
    for (let i = 0; i < this.data.medicalExemptions.length; i++) {
      const med = this.data.medicalExemptions[i];
      if (!medicalByStudent[med.studentId]) medicalByStudent[med.studentId] = [];
      medicalByStudent[med.studentId].push(med);
    }

    const marksByStudent = {};
    for (let i = 0; i < this.data.midtermMarks.length; i++) {
      const mrk = this.data.midtermMarks[i];
      if (!marksByStudent[mrk.studentId]) marksByStudent[mrk.studentId] = [];
      marksByStudent[mrk.studentId].push(mrk);
    }

    const subjects = this.data.subjects;
    const computedStudents = [];
    const studentsMap = {};

    let totalBatchPercentage = 0;
    let criticalCount = 0;
    let warningCount = 0;
    let safeCount = 0;

    for (let i = 0; i < this.data.students.length; i++) {
      const student = this.data.students[i];
      const studentId = student.id;

      let totalClassesAllSubjects = 0;
      let totalAttendedAllSubjects = 0;
      let totalExcusedAllSubjects = 0;

      const studentRecsMap = recordsByStudentSubject[studentId] || {};

      const subjectBreakdown = subjects.map(sub => {
        const records = studentRecsMap[sub.id] || [];
        const totalClasses = records.length;
        let presentCount = 0;
        let lateCount = 0;
        let absentCount = 0;
        let excusedCount = 0;

        for (let j = 0; j < records.length; j++) {
          const r = records[j];
          if (r.medicalExempted || r.status === 'EXCUSED') {
            excusedCount++;
            presentCount++;
          } else if (r.status === 'PRESENT') {
            presentCount++;
          } else if (r.status === 'LATE') {
            lateCount++;
            presentCount++;
          } else {
            absentCount++;
          }
        }

        const attended = presentCount;
        const percentage = totalClasses > 0 ? Number(((attended / totalClasses) * 100).toFixed(1)) : 100;
        const riskTier = classifyRisk(percentage);
        const classesNeeded = calculateClassesNeeded(attended, totalClasses);
        const bunkAllowance = calculateBunkAllowance(attended, totalClasses);

        totalClassesAllSubjects += totalClasses;
        totalAttendedAllSubjects += attended;
        totalExcusedAllSubjects += excusedCount;

        return {
          subjectId: sub.id,
          code: sub.code,
          name: sub.name,
          shortName: sub.shortName,
          credits: sub.credits,
          facultyName: sub.facultyName,
          room: sub.room,
          color: sub.color,
          totalClasses,
          attended,
          absentCount,
          lateCount,
          excusedCount,
          percentage,
          riskTier,
          classesNeeded,
          bunkAllowance
        };
      });

      const overallPercentage = totalClassesAllSubjects > 0
        ? Number(((totalAttendedAllSubjects / totalClassesAllSubjects) * 100).toFixed(1))
        : 100;
      const overallRiskTier = classifyRisk(overallPercentage);
      const overallClassesNeeded = calculateClassesNeeded(totalAttendedAllSubjects, totalClassesAllSubjects);
      const overallBunkAllowance = calculateBunkAllowance(totalAttendedAllSubjects, totalClassesAllSubjects);

      const criticalSubjects = subjectBreakdown.filter(s => s.riskTier === 'CRITICAL');
      const warningSubjects = subjectBreakdown.filter(s => s.riskTier === 'WARNING');

      const computedStudent = {
        ...student,
        overallPercentage,
        overallRiskTier,
        totalClasses: totalClassesAllSubjects,
        totalAttended: totalAttendedAllSubjects,
        totalExcused: totalExcusedAllSubjects,
        overallClassesNeeded,
        overallBunkAllowance,
        criticalSubjectCount: criticalSubjects.length,
        warningSubjectCount: warningSubjects.length,
        hasSubjectShortage: criticalSubjects.length > 0 || warningSubjects.length > 0,
        subjectBreakdown,
        interventions: interventionsByStudent[studentId] || [],
        medicalLeaves: medicalByStudent[studentId] || [],
        marks: marksByStudent[studentId] || []
      };

      computedStudents.push(computedStudent);
      studentsMap[studentId] = computedStudent;

      totalBatchPercentage += overallPercentage;
      if (overallRiskTier === 'CRITICAL' || criticalSubjects.length > 0) {
        criticalCount++;
      } else if (overallRiskTier === 'WARNING' || warningSubjects.length > 0) {
        warningCount++;
      } else {
        safeCount++;
      }
    }

    const totalStudents = computedStudents.length;
    const avgAttendance = totalStudents > 0 ? Number((totalBatchPercentage / totalStudents).toFixed(1)) : 0;
    const pendingMedicalCount = this.data.medicalExemptions.filter(m => m.status === 'PENDING').length;
    const openInterventionsCount = this.data.mentoringInterventions.filter(m => m.status !== 'Resolved').length;

    this.cache.computedStudents = computedStudents;
    this.cache.studentsMap = studentsMap;
    this.cache.overview = {
      totalStudents,
      avgAttendance,
      criticalCount,
      warningCount,
      safeCount,
      pendingMedicalCount,
      openInterventionsCount,
      totalSubjects: this.data.subjects.length,
      totalSessionsConducted: this.data.sessions.length
    };
  }

  save() {
    try {
      const tempPath = `${DB_PATH}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(this.data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_PATH);
    } catch (err) {
      console.error('Error saving database:', err);
    }
  }

  reset() {
    console.log('Initializing fresh seed database...');
    this.data = generateSeedData();
    this.save();
    this.rebuildCache();
    console.log(`Seeded ${this.data.students.length} students, ${this.data.subjects.length} subjects, ${this.data.sessions.length} sessions, and ${this.data.attendanceRecords.length} attendance records.`);
  }

  // --- Student Queries & Calculations (O(1) with in-memory cache) ---
  getAllStudents() {
    if (!this.cache.computedStudents) {
      this.rebuildCache();
    }
    return this.cache.computedStudents;
  }

  getStudentById(studentId) {
    if (!this.cache.studentsMap) {
      this.rebuildCache();
    }
    return this.cache.studentsMap[studentId] || null;
  }

  // --- Overview & Dashboard Metrics (O(1)) ---
  getDashboardOverview() {
    if (!this.cache.overview) {
      this.rebuildCache();
    }
    return this.cache.overview;
  }

  // --- Subjects ---
  getAllSubjects() {
    return this.data.subjects.map(sub => {
      const sessions = this.data.sessions.filter(s => s.subjectId === sub.id);
      const records = this.data.attendanceRecords.filter(r => r.subjectId === sub.id);
      
      const totalRecords = records.length;
      const attendedRecords = records.filter(r => r.status === 'PRESENT' || r.status === 'LATE' || r.medicalExempted).length;
      const avgPercentage = totalRecords > 0 ? Number(((attendedRecords / totalRecords) * 100).toFixed(1)) : 100;

      const studentMap = {};
      for (let i = 0; i < records.length; i++) {
        const r = records[i];
        if (!studentMap[r.studentId]) studentMap[r.studentId] = { attended: 0, total: 0 };
        studentMap[r.studentId].total++;
        if (r.status === 'PRESENT' || r.status === 'LATE' || r.medicalExempted) {
          studentMap[r.studentId].attended++;
        }
      }

      let criticalStudents = 0;
      let warningStudents = 0;
      let safeStudents = 0;

      Object.values(studentMap).forEach(st => {
        const p = st.total > 0 ? (st.attended / st.total) * 100 : 100;
        if (p < 65) criticalStudents++;
        else if (p < 75) warningStudents++;
        else safeStudents++;
      });

      return {
        ...sub,
        totalSessions: sessions.length,
        avgPercentage,
        criticalStudents,
        warningStudents,
        safeStudents
      };
    });
  }

  // --- Attendance Marking (Faculty) ---
  markSessionAttendance({ subjectId, date, slot, topic, records, facultyId, facultyName }) {
    const sessionId = `SES_${subjectId}_${Date.now()}`;
    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;

    const newRecords = [];

    for (let i = 0; i < records.length; i++) {
      const r = records[i];
      const status = r.status || 'PRESENT';
      if (status === 'PRESENT') presentCount++;
      else if (status === 'LATE') {
        lateCount++;
        presentCount++;
      } else absentCount++;

      newRecords.push({
        id: `REC_${sessionId}_${r.studentId}`,
        sessionId,
        subjectId,
        studentId: r.studentId,
        status,
        timestamp: `${date}T${(slot || '09:00').slice(0, 5)}:00Z`,
        remarks: r.remarks || ''
      });
    }

    const newSession = {
      id: sessionId,
      subjectId,
      facultyId: facultyId || 'FAC001',
      facultyName: facultyName || 'Faculty Mentor',
      date,
      slot: slot || '09:00 - 10:00 AM',
      topic: topic || 'Regular Lecture',
      totalStudents: records.length,
      presentCount,
      absentCount,
      lateCount,
      createdAt: new Date().toISOString()
    };

    this.data.sessions.push(newSession);
    this.data.attendanceRecords.push(...newRecords);
    this.save();
    this.rebuildCache();

    return {
      session: newSession,
      recordsCount: newRecords.length
    };
  }

  // --- Mentoring Interventions ---
  logMentoringIntervention(interventionData) {
    const id = `MNT_${Date.now()}`;
    const newIntervention = {
      id,
      studentId: interventionData.studentId,
      studentName: interventionData.studentName,
      rollNo: interventionData.rollNo,
      mentorName: interventionData.mentorName || 'Prof. Dr. Arvind Menon',
      date: new Date().toISOString(),
      riskTierAtTime: interventionData.riskTierAtTime || 'CRITICAL',
      currentPercentage: interventionData.currentPercentage,
      subjectId: interventionData.subjectId || 'ALL',
      subjectName: interventionData.subjectName || 'Overall Academics',
      classesNeeded: interventionData.classesNeeded || 0,
      interventionType: interventionData.interventionType || 'One-on-One Counseling',
      counselingNotes: interventionData.counselingNotes || '',
      actionPlan: interventionData.actionPlan || '',
      status: interventionData.status || 'In Progress',
      nextFollowUpDate: interventionData.nextFollowUpDate || null
    };

    this.data.mentoringInterventions.unshift(newIntervention);
    this.save();
    this.rebuildCache();
    return newIntervention;
  }

  updateMentoringStatus(id, { status, counselingNotes, actionPlan }) {
    const item = this.data.mentoringInterventions.find(m => m.id === id);
    if (!item) return null;
    if (status) item.status = status;
    if (counselingNotes) item.counselingNotes = counselingNotes;
    if (actionPlan) item.actionPlan = actionPlan;
    this.save();
    this.rebuildCache();
    return item;
  }

  // --- Simulated Alerts ---
  logAlert(alertData) {
    const id = `ALT_${Date.now()}`;
    const newAlert = {
      id,
      studentId: alertData.studentId,
      studentName: alertData.studentName,
      rollNo: alertData.rollNo,
      recipientType: alertData.recipientType || 'BOTH',
      studentEmail: alertData.studentEmail,
      parentEmail: alertData.parentEmail,
      riskTier: alertData.riskTier,
      attendancePercent: alertData.attendancePercent,
      consecutiveClassesNeeded: alertData.consecutiveClassesNeeded,
      subject: alertData.subject || 'Automated Attendance Shortage Alert',
      bodySnippet: alertData.bodySnippet || '',
      bodyHtml: alertData.bodyHtml || '',
      sentAt: new Date().toISOString(),
      triggeredBy: alertData.triggeredBy || 'Faculty Mentor Intervention',
      status: 'SENT (SIMULATED)'
    };

    this.data.alertLogs.unshift(newAlert);
    this.save();
    return newAlert;
  }

  // --- Medical Exemptions ---
  submitMedicalExemption(exemptionData) {
    const id = `MED_${Date.now()}`;
    const newExemption = {
      id,
      studentId: exemptionData.studentId,
      studentName: exemptionData.studentName,
      rollNo: exemptionData.rollNo,
      subjectIds: exemptionData.subjectIds || [],
      startDate: exemptionData.startDate,
      endDate: exemptionData.endDate,
      sessionsAffectedCount: Number(exemptionData.sessionsAffectedCount) || 1,
      reason: exemptionData.reason,
      doctorName: exemptionData.doctorName,
      hospital: exemptionData.hospital,
      certificateUrl: exemptionData.certificateUrl || '/uploads/mock_medical_certificate.pdf',
      status: 'PENDING',
      appliedAt: new Date().toISOString(),
      reviewedBy: null,
      reviewedAt: null,
      remarks: exemptionData.remarks || ''
    };

    this.data.medicalExemptions.unshift(newExemption);
    this.save();
    this.rebuildCache();
    return newExemption;
  }

  reviewMedicalExemption(id, { status, reviewedBy, remarks }) {
    const item = this.data.medicalExemptions.find(m => m.id === id);
    if (!item) return null;

    item.status = status;
    item.reviewedBy = reviewedBy || 'Prof. Dr. Arvind Menon';
    item.reviewedAt = new Date().toISOString();
    item.remarks = remarks || item.remarks;

    if (status === 'APPROVED') {
      const studentRecs = this.data.attendanceRecords.filter(r => r.studentId === item.studentId);
      studentRecs.forEach(rec => {
        const session = this.data.sessions.find(s => s.id === rec.sessionId);
        if (session) {
          const sDate = session.date;
          if (sDate >= item.startDate && sDate <= item.endDate) {
            if (rec.status === 'ABSENT') {
              rec.medicalExempted = true;
              rec.status = 'EXCUSED';
              rec.remarks = `Medical condonation: ${item.reason} (${item.id})`;
            }
          }
        }
      });
    }

    this.save();
    this.rebuildCache();
    return item;
  }

  // --- Analytics & Scatter Plot Correlation ---
  getCorrelationData() {
    if (this.cache.correlation) {
      return this.cache.correlation;
    }

    const students = this.getAllStudents();
    const dataPoints = [];
    const xAttendance = [];
    const yMarks = [];

    this.data.midtermMarks.forEach(m => {
      const student = students.find(s => s.id === m.studentId);
      if (!student) return;

      const subStats = student.subjectBreakdown.find(s => s.subjectId === m.subjectId);
      const currentAtt = subStats ? subStats.percentage : m.attendancePercentage;

      dataPoints.push({
        studentId: m.studentId,
        studentName: m.studentName,
        rollNo: student.rollNo,
        subjectId: m.subjectId,
        subjectName: m.subjectName,
        attendancePercentage: currentAtt,
        midtermMarks: m.midtermMarks,
        maxMidtermMarks: m.maxMidtermMarks,
        assignmentMarks: m.assignmentMarks,
        totalPercentage: m.totalPercentage,
        riskTier: classifyRisk(currentAtt)
      });

      xAttendance.push(currentAtt);
      yMarks.push(m.totalPercentage);
    });

    let r = 0;
    const n = xAttendance.length;
    if (n > 0) {
      let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
      for (let i = 0; i < n; i++) {
        sumX += xAttendance[i];
        sumY += yMarks[i];
        sumXY += xAttendance[i] * yMarks[i];
        sumX2 += xAttendance[i] * xAttendance[i];
        sumY2 += yMarks[i] * yMarks[i];
      }
      const num = (n * sumXY) - (sumX * sumY);
      const den = Math.sqrt(((n * sumX2) - (sumX * sumX)) * ((n * sumY2) - (sumY * sumY)));
      r = den === 0 ? 0 : Number((num / den).toFixed(3));
    }

    const result = {
      correlationCoefficient: r,
      interpretation: r > 0.7 ? 'Strong Positive Correlation' : r > 0.4 ? 'Moderate Positive Correlation' : 'Weak Correlation',
      dataPoints
    };

    this.cache.correlation = result;
    return result;
  }
}

export const db = new Database();
