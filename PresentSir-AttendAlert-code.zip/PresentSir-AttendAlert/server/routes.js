import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { db } from './db.js';
import { calculateClassesNeeded, calculateBunkAllowance } from './calc.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Multer storage for medical certificates and CSV rosters
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const basename = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    cb(null, `${basename}_${Date.now()}${ext}`);
  }
});
const upload = multer({ storage });

export const router = express.Router();

// --- System & Overview Stats ---
router.get('/stats/overview', (req, res) => {
  try {
    const overview = db.getDashboardOverview();
    res.json({ success: true, data: overview });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Students ---
router.get('/students', (req, res) => {
  try {
    const { search, riskTier, subjectId } = req.query;
    let students = db.getAllStudents();

    if (riskTier && riskTier !== 'ALL') {
      students = students.filter(s => {
        if (riskTier === 'CRITICAL') {
          return s.overallRiskTier === 'CRITICAL' || s.criticalSubjectCount > 0;
        }
        if (riskTier === 'WARNING') {
          return s.overallRiskTier === 'WARNING' || (s.warningSubjectCount > 0 && s.overallRiskTier !== 'CRITICAL');
        }
        if (riskTier === 'SAFE') {
          return s.overallRiskTier === 'SAFE' && s.criticalSubjectCount === 0 && s.warningSubjectCount === 0;
        }
        return true;
      });
    }

    if (subjectId && subjectId !== 'ALL') {
      students = students.filter(s => {
        const sub = s.subjectBreakdown.find(b => b.subjectId === subjectId);
        return sub !== undefined;
      });
    }

    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      students = students.filter(
        s => s.name.toLowerCase().includes(q) ||
             s.rollNo.toLowerCase().includes(q) ||
             s.email.toLowerCase().includes(q)
      );
    }

    res.json({ success: true, data: students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/students/:id', (req, res) => {
  try {
    const student = db.getStudentById(req.params.id);
    if (!student) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }

    // Attach student attendance log history across all sessions
    const studentHistory = db.data.attendanceRecords
      .filter(r => r.studentId === req.params.id)
      .map(r => {
        const session = db.data.sessions.find(s => s.id === r.sessionId);
        const subject = db.data.subjects.find(s => s.id === r.subjectId);
        return {
          id: r.id,
          sessionId: r.sessionId,
          subjectId: r.subjectId,
          subjectCode: subject ? subject.code : r.subjectId,
          subjectName: subject ? subject.name : '',
          date: session ? session.date : '',
          slot: session ? session.slot : '',
          topic: session ? session.topic : '',
          facultyName: session ? session.facultyName : '',
          status: r.status,
          medicalExempted: !!r.medicalExempted,
          remarks: r.remarks || ''
        };
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    res.json({
      success: true,
      data: {
        ...student,
        attendanceHistory: studentHistory
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Subjects ---
router.get('/subjects', (req, res) => {
  try {
    const subjects = db.getAllSubjects();
    res.json({ success: true, data: subjects });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/subjects/:id/roster', (req, res) => {
  try {
    const subject = db.data.subjects.find(s => s.id === req.params.id);
    if (!subject) {
      return res.status(404).json({ success: false, error: 'Subject not found' });
    }

    const students = db.getAllStudents().map(s => {
      const subStat = s.subjectBreakdown.find(b => b.subjectId === req.params.id);
      return {
        id: s.id,
        rollNo: s.rollNo,
        name: s.name,
        email: s.email,
        attended: subStat ? subStat.attended : 0,
        totalClasses: subStat ? subStat.totalClasses : 0,
        percentage: subStat ? subStat.percentage : 100,
        riskTier: subStat ? subStat.riskTier : 'SAFE',
        classesNeeded: subStat ? subStat.classesNeeded : 0,
        bunkAllowance: subStat ? subStat.bunkAllowance : 0
      };
    });

    res.json({
      success: true,
      data: {
        subject,
        students
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Attendance Sessions & Marking ---
router.post('/attendance/mark', (req, res) => {
  try {
    const { subjectId, date, slot, topic, records, facultyId, facultyName } = req.body;
    if (!subjectId || !date || !records || !Array.isArray(records)) {
      return res.status(400).json({ success: false, error: 'Invalid attendance submission payload' });
    }

    const result = db.markSessionAttendance({
      subjectId,
      date,
      slot,
      topic,
      records,
      facultyId,
      facultyName
    });

    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/attendance/sessions', (req, res) => {
  try {
    const sessions = [...db.data.sessions].reverse().map(sess => {
      const sub = db.data.subjects.find(s => s.id === sess.subjectId);
      return {
        ...sess,
        subjectCode: sub ? sub.code : sess.subjectId,
        subjectName: sub ? sub.name : ''
      };
    });
    res.json({ success: true, data: sessions });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/attendance/sessions/:id', (req, res) => {
  try {
    const session = db.data.sessions.find(s => s.id === req.params.id);
    if (!session) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    const records = db.data.attendanceRecords
      .filter(r => r.sessionId === req.params.id)
      .map(r => {
        const student = db.data.students.find(s => s.id === r.studentId);
        return {
          ...r,
          studentName: student ? student.name : r.studentId,
          rollNo: student ? student.rollNo : ''
        };
      });

    const subject = db.data.subjects.find(s => s.id === session.subjectId);

    res.json({
      success: true,
      data: {
        session: {
          ...session,
          subjectCode: subject ? subject.code : session.subjectId,
          subjectName: subject ? subject.name : ''
        },
        records
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Mentoring Interventions ---
router.get('/mentoring/logs', (req, res) => {
  try {
    const { studentId, status } = req.query;
    let logs = [...db.data.mentoringInterventions];

    if (studentId) {
      logs = logs.filter(l => l.studentId === studentId);
    }
    if (status && status !== 'ALL') {
      logs = logs.filter(l => l.status === status);
    }

    res.json({ success: true, data: logs });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/mentoring/log', (req, res) => {
  try {
    const {
      studentId,
      studentName,
      rollNo,
      mentorName,
      riskTierAtTime,
      currentPercentage,
      subjectId,
      subjectName,
      classesNeeded,
      interventionType,
      counselingNotes,
      actionPlan,
      status,
      nextFollowUpDate
    } = req.body;

    if (!studentId || !studentName) {
      return res.status(400).json({ success: false, error: 'Student ID and name are required' });
    }

    const intervention = db.logMentoringIntervention({
      studentId,
      studentName,
      rollNo,
      mentorName,
      riskTierAtTime,
      currentPercentage,
      subjectId,
      subjectName,
      classesNeeded,
      interventionType,
      counselingNotes,
      actionPlan,
      status,
      nextFollowUpDate
    });

    res.json({ success: true, data: intervention });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.patch('/mentoring/logs/:id', (req, res) => {
  try {
    const updated = db.updateMentoringStatus(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Intervention not found' });
    }
    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Automated Parent/Student Alerts ---
router.post('/alerts/send', (req, res) => {
  try {
    const {
      studentId,
      recipientType = 'BOTH',
      customSubject,
      customRemarks
    } = req.body;

    const student = db.getStudentById(studentId);
    if (!student) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }

    const criticalSubs = student.subjectBreakdown.filter(s => s.riskTier === 'CRITICAL');
    const warningSubs = student.subjectBreakdown.filter(s => s.riskTier === 'WARNING');

    const subjectLine = customSubject || `ACADEMIC DETENTION WARNING: Attendance Shortage (${student.overallPercentage}%) - ${student.name} (${student.rollNo})`;

    const bodySnippet = `Dear Parent / Guardian, this is an official notification from the Department of Computer Science & Engineering. Student ${student.name} (Roll No: ${student.rollNo}) has accumulated an attendance shortage of ${student.overallPercentage}% (University Mandatory Threshold: 75%). The student must attend ${student.overallClassesNeeded} consecutive upcoming classes without absence to regain exam eligibility.`;

    const bodyHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 8px;">
        <div style="background: #b91c1c; color: white; padding: 16px; border-radius: 6px; text-align: center;">
          <h2 style="margin: 0; font-size: 20px;">OFFICIAL ATTENDANCE SHORTAGE NOTICE</h2>
          <p style="margin: 4px 0 0 0; font-size: 13px;">Department of Computer Science & Engineering • Academic Early-Warning</p>
        </div>
        <div style="padding: 20px 0;">
          <p>Dear <strong>Parent / Guardian of ${student.name}</strong>,</p>
          <p>This automated early-warning alert informs you that your ward's attendance in the ongoing Semester ${student.semester} has fallen below the mandatory <strong>75% statutory requirement</strong>.</p>
          
          <table style="width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px;">
            <tr style="background: #f8fafc;"><td style="padding: 8px; border: 1px solid #cbd5e1;"><strong>Student Name</strong></td><td style="padding: 8px; border: 1px solid #cbd5e1;">${student.name}</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #cbd5e1;"><strong>Roll Number</strong></td><td style="padding: 8px; border: 1px solid #cbd5e1;">${student.rollNo}</td></tr>
            <tr style="background: #f8fafc;"><td style="padding: 8px; border: 1px solid #cbd5e1;"><strong>Overall Attendance</strong></td><td style="padding: 8px; border: 1px solid #cbd5e1; color: #dc2626; font-weight: bold;">${student.overallPercentage}% (${student.totalAttended} / ${student.totalClasses} classes)</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #cbd5e1;"><strong>Recovery Requirement</strong></td><td style="padding: 8px; border: 1px solid #cbd5e1; color: #b91c1c; font-weight: bold;">Must attend next ${student.overallClassesNeeded} consecutive classes without absence</td></tr>
          </table>

          <h4 style="margin: 16px 0 8px 0; color: #334155;">Subject-wise Breakdown:</h4>
          <ul>
            ${student.subjectBreakdown.map(sub => `
              <li style="margin-bottom: 4px;">
                <strong>${sub.code} - ${sub.name}:</strong> ${sub.percentage}% 
                <span style="color: ${sub.riskTier === 'CRITICAL' ? '#dc2626' : sub.riskTier === 'WARNING' ? '#d97706' : '#16a34a'}; font-weight: bold;">[${sub.riskTier}]</span>
                ${sub.classesNeeded > 0 ? ` — Needs ${sub.classesNeeded} consecutive classes to recover` : ' — Eligible'}
              </li>
            `).join('')}
          </ul>

          ${customRemarks ? `<p style="background: #fef2f2; border-left: 4px solid #ef4444; padding: 12px; margin-top: 16px;"><strong>Mentor Remarks:</strong> ${customRemarks}</p>` : ''}

          <p style="margin-top: 24px; font-size: 13px; color: #64748b;">
            Please contact Academic Mentor <strong>${student.mentorName}</strong> immediately for counseling and intervention.<br/>
            Issued by AttendAlert Early-Warning System.
          </p>
        </div>
      </div>
    `;

    const alertLog = db.logAlert({
      studentId: student.id,
      studentName: student.name,
      rollNo: student.rollNo,
      recipientType,
      studentEmail: student.email,
      parentEmail: student.parentEmail,
      riskTier: student.overallRiskTier,
      attendancePercent: student.overallPercentage,
      consecutiveClassesNeeded: student.overallClassesNeeded,
      subject: subjectLine,
      bodySnippet,
      bodyHtml,
      triggeredBy: 'Mentor Action Hub'
    });

    res.json({
      success: true,
      message: `Simulated warning dispatch sent successfully to ${recipientType === 'BOTH' ? 'Student & Parent' : recipientType}`,
      data: alertLog
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/alerts/history', (req, res) => {
  try {
    res.json({ success: true, data: db.data.alertLogs });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Medical Leave Exemption Workflow ---
router.get('/medical/requests', (req, res) => {
  try {
    res.json({ success: true, data: db.data.medicalExemptions });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/medical/submit', upload.single('certificate'), (req, res) => {
  try {
    const {
      studentId,
      startDate,
      endDate,
      sessionsAffectedCount,
      reason,
      doctorName,
      hospital,
      remarks
    } = req.body;

    const student = db.data.students.find(s => s.id === studentId);
    if (!student) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }

    const certificateUrl = req.file
      ? `/uploads/${req.file.filename}`
      : '/uploads/sample_medical_certificate.pdf';

    const newExemption = db.submitMedicalExemption({
      studentId: student.id,
      studentName: student.name,
      rollNo: student.rollNo,
      startDate,
      endDate,
      sessionsAffectedCount,
      reason,
      doctorName,
      hospital,
      certificateUrl,
      remarks
    });

    res.json({ success: true, data: newExemption });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/medical/:id/review', (req, res) => {
  try {
    const { status, reviewedBy, remarks } = req.body;
    if (!status || !['APPROVED', 'REJECTED'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Status must be APPROVED or REJECTED' });
    }

    const reviewed = db.reviewMedicalExemption(req.params.id, {
      status,
      reviewedBy,
      remarks
    });

    if (!reviewed) {
      return res.status(404).json({ success: false, error: 'Medical exemption not found' });
    }

    res.json({
      success: true,
      message: `Medical exemption has been ${status.toLowerCase()} and attendance records recalculated.`,
      data: reviewed
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Analytics & Scatter Plot Correlation ---
router.get('/analytics/correlation', (req, res) => {
  try {
    const correlation = db.getCorrelationData();
    res.json({ success: true, data: correlation });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- CSV Export & Import ---
router.get('/roster/export-csv', (req, res) => {
  try {
    const students = db.getAllStudents();
    const subjects = db.data.subjects;

    // Build CSV Header
    let csv = 'Roll No,Student Name,Email,Department,Semester,Section,Overall Attended,Overall Total,Overall Percentage,Risk Tier,Consecutive Classes Needed to Reach 75%,Bunk Allowance';
    subjects.forEach(sub => {
      csv += `,${sub.code} Attended,${sub.code} Total,${sub.code} %,${sub.code} Risk,${sub.code} Needed`;
    });
    csv += '\n';

    // Build Rows
    students.forEach(s => {
      csv += `"${s.rollNo}","${s.name}","${s.email}","${s.department}",${s.semester},"${s.section}",${s.totalAttended},${s.totalClasses},${s.overallPercentage}%,"${s.overallRiskTier}",${s.overallClassesNeeded},${s.overallBunkAllowance}`;

      subjects.forEach(sub => {
        const b = s.subjectBreakdown.find(x => x.subjectId === sub.id) || {};
        csv += `,${b.attended || 0},${b.totalClasses || 0},${b.percentage || 0}%,${b.riskTier || 'SAFE'},${b.classesNeeded || 0}`;
      });

      csv += '\n';
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="PresentSir_Attendance_Roster_Report.csv"');
    res.send(csv);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/roster/import-csv', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'No CSV file uploaded' });
    }

    const content = fs.readFileSync(req.file.path, 'utf-8');
    const lines = content.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length < 2) {
      return res.status(400).json({ success: false, error: 'CSV file contains no data rows' });
    }

    const header = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    let importedStudentsCount = 0;

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g, ''));
      if (cols.length >= 3) {
        const rollNo = cols[0];
        const name = cols[1];
        const email = cols[2];

        // Check if student exists
        let existing = db.data.students.find(s => s.rollNo === rollNo);
        if (!existing) {
          const newStudent = {
            id: `STU${String(db.data.students.length + 1).padStart(3, '0')}`,
            rollNo,
            name,
            email,
            parentEmail: `parent.${rollNo.toLowerCase()}@parentmail.com`,
            parentPhone: '+91 99000 00000',
            semester: 5,
            section: 'A',
            department: 'Computer Science & Engineering',
            mentorName: 'Prof. Dr. Arvind Menon'
          };
          db.data.students.push(newStudent);
          importedStudentsCount++;
        }
      }
    }

    db.save();
    res.json({
      success: true,
      message: `CSV roster processed successfully! ${importedStudentsCount} new students registered.`,
      importedCount: importedStudentsCount
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Demo State Reset ---
router.post('/reset-seed', (req, res) => {
  try {
    db.reset();
    res.json({ success: true, message: 'Database reset to original hackathon seed scenario!' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});
