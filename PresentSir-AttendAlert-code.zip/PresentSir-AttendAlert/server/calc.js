/**
 * PresentSir / AttendAlert - Core Attendance & Risk Calculation Engine
 * 
 * Thresholds:
 * - SAFE: >= 75%
 * - WARNING: 65% - 74.99%
 * - CRITICAL: < 65%
 */

export const THRESHOLD_SAFE = 0.75;
export const THRESHOLD_CRITICAL = 0.65;

/**
 * Classify risk tier based on attendance percentage
 * @param {number} percentage - Attendance percentage (0 - 100)
 * @returns {'SAFE' | 'WARNING' | 'CRITICAL'}
 */
export function classifyRisk(percentage) {
  if (percentage >= 75) return 'SAFE';
  if (percentage >= 65) return 'WARNING';
  return 'CRITICAL';
}

/**
 * Calculates recovery classes required to reach 75% threshold
 * Closed-form algebraic formula:
 * (Attended + x) / (Total + x) >= 0.75
 * Attended + x >= 0.75 * Total + 0.75 * x
 * 0.25 * x >= 0.75 * Total - Attended
 * x = ceil((0.75 * Total - Attended) / 0.25)
 * 
 * @param {number} attended - Number of classes attended
 * @param {number} total - Total classes conducted
 * @returns {number} Consecutive classes student must attend without missing
 */
export function calculateClassesNeeded(attended, total) {
  if (total <= 0) return 0;
  const currentRatio = attended / total;
  if (currentRatio >= THRESHOLD_SAFE) return 0;

  const delta = (THRESHOLD_SAFE * total) - attended;
  const needed = Math.ceil(delta / (1 - THRESHOLD_SAFE));
  return Math.max(0, needed);
}

/**
 * Calculates how many classes a safe student can afford to miss (Bunk Allowance)
 * Attended / (Total + y) >= 0.75
 * Attended >= 0.75 * (Total + y)
 * Attended - 0.75 * Total >= 0.75 * y
 * y = floor((Attended - 0.75 * Total) / 0.75)
 * 
 * @param {number} attended 
 * @param {number} total 
 * @returns {number}
 */
export function calculateBunkAllowance(attended, total) {
  if (total <= 0) return 0;
  const currentRatio = attended / total;
  if (currentRatio < THRESHOLD_SAFE) return 0;

  const surplus = attended - (THRESHOLD_SAFE * total);
  const allowance = Math.floor(surplus / THRESHOLD_SAFE);
  return Math.max(0, allowance);
}

/**
 * Calculate Pearson correlation coefficient between two numeric arrays
 */
export function calculatePearsonCorrelation(xArr, yArr) {
  const n = xArr.length;
  if (n === 0 || n !== yArr.length) return 0;

  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumX2 = 0;
  let sumY2 = 0;

  for (let i = 0; i < n; i++) {
    const x = xArr[i];
    const y = yArr[i];
    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumX2 += x * x;
    sumY2 += y * y;
  }

  const numerator = (n * sumXY) - (sumX * sumY);
  const denominator = Math.sqrt(
    ((n * sumX2) - (sumX * sumX)) * ((n * sumY2) - (sumY * sumY))
  );

  if (denominator === 0) return 0;
  return Number((numerator / denominator).toFixed(4));
}
