import assert from 'assert';

console.log('--- Testing Full End-to-End Flow Against Live Server (http://localhost:5001) ---');

async function runTests() {
  const BASE = 'http://localhost:5001/api';

  // 1. Health check
  const healthRes = await fetch('http://localhost:5001/health');
  assert.strictEqual(healthRes.status, 200);
  const health = await healthRes.json();
  console.log('✓ Health check passed:', health.service);

  // 2. Overview metrics
  const overviewRes = await fetch(`${BASE}/stats/overview`);
  assert.strictEqual(overviewRes.status, 200);
  const overview = (await overviewRes.json()).data;
  console.log(`✓ Overview: ${overview.totalStudents} students, ${overview.avgAttendance}% avg attendance, ${overview.criticalCount} critical`);
  assert.strictEqual(overview.totalStudents, 30);
  assert.ok(overview.criticalCount >= 5);

  // 3. Inspect Rahul Verma (STU001)
  const rahulRes = await fetch(`${BASE}/students/STU001`);
  assert.strictEqual(rahulRes.status, 200);
  const rahul = (await rahulRes.json()).data;
  console.log(`✓ Rahul Verma: ${rahul.name} (${rahul.rollNo}), Overall: ${rahul.overallPercentage}%`);
  const dsa = rahul.subjectBreakdown.find(s => s.subjectId === 'CS501');
  assert.ok(dsa, 'DSA subject must exist for Rahul');
  console.log(`  DSA Attended: ${dsa.attended}/${dsa.totalClasses} (${dsa.percentage}%), Risk: ${dsa.riskTier}, Classes Needed: ${dsa.classesNeeded}`);
  assert.strictEqual(dsa.classesNeeded, 8, 'Rahul must need exactly 8 consecutive classes in DSA');

  // 4. Log Mentoring Intervention for Rahul Verma
  const mentorRes = await fetch(`${BASE}/mentoring/log`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      studentId: 'STU001',
      studentName: 'Rahul Verma',
      rollNo: '21CS042',
      mentorName: 'Prof. Dr. Arvind Menon',
      currentPercentage: dsa.percentage,
      subjectId: 'CS501',
      subjectName: 'Data Structures & Algorithms',
      classesNeeded: 8,
      interventionType: 'One-on-One Counseling',
      counselingNotes: 'Discussed morning commute issues. Rahul committed to 100% attendance in DSA lectures.',
      actionPlan: 'Signed recovery pledge. Next review scheduled in 7 days.',
      status: 'In Progress'
    })
  });
  assert.strictEqual(mentorRes.status, 200);
  const mentorData = (await mentorRes.json()).data;
  console.log('✓ Mentoring Intervention logged successfully:', mentorData.id);

  // 5. Dispatch Simulated Warning Alert
  const alertRes = await fetch(`${BASE}/alerts/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      studentId: 'STU001',
      recipientType: 'BOTH',
      customRemarks: 'Urgent: Attend next 8 classes to avoid exam detention.'
    })
  });
  assert.strictEqual(alertRes.status, 200);
  const alertData = await alertRes.json();
  console.log('✓ Alert Dispatched:', alertData.message);

  // 6. Test Medical Leave Exemption Approval (Sneha Deshmukh MED_001)
  const medRes = await fetch(`${BASE}/medical/requests`);
  const medList = (await medRes.json()).data;
  const pendingMed = medList.find(m => m.status === 'PENDING');
  if (pendingMed) {
    console.log(`✓ Found pending medical exemption: ${pendingMed.id} for ${pendingMed.studentName}`);
    const reviewRes = await fetch(`${BASE}/medical/${pendingMed.id}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'APPROVED',
        reviewedBy: 'Prof. Dr. Arvind Menon',
        remarks: 'Hospital certificate verified. Condonation granted.'
      })
    });
    assert.strictEqual(reviewRes.status, 200);
    const reviewData = await reviewRes.json();
    console.log('✓ Medical exemption approved & attendance condoned:', reviewData.message);
  }

  // 7. Test Attendance Session Marking
  const markRes = await fetch(`${BASE}/attendance/mark`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      subjectId: 'CS501',
      date: '2026-11-19',
      slot: '09:00 - 10:00 AM',
      topic: 'Live Verification: Advanced Dynamic Programming',
      records: [
        { studentId: 'STU001', status: 'PRESENT' },
        { studentId: 'STU002', status: 'PRESENT' }
      ]
    })
  });
  assert.strictEqual(markRes.status, 200);
  const markData = (await markRes.json()).data;
  console.log('✓ Attendance marked for new session:', markData.session.id, 'Records:', markData.recordsCount);

  // 8. Test Marks vs Attendance Correlation API
  const corrRes = await fetch(`${BASE}/analytics/correlation`);
  assert.strictEqual(corrRes.status, 200);
  const corrData = (await corrRes.json()).data;
  console.log(`✓ Marks Correlation: r = ${corrData.correlationCoefficient} (${corrData.interpretation}), Points: ${corrData.dataPoints.length}`);
  assert.ok(corrData.correlationCoefficient > 0.6);

  console.log('\n>>> ALL FULLSTACK END-TO-END WORKFLOW TESTS PASSED 100%! <<<');
}

runTests().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});
