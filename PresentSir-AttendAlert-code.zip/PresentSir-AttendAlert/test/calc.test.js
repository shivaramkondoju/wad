import assert from 'assert';
import {
  classifyRisk,
  calculateClassesNeeded,
  calculateBunkAllowance,
  calculatePearsonCorrelation
} from '../server/calc.js';

console.log('Running PresentSir / AttendAlert Calculation Engine Tests...\n');

// 1. Risk Classifier Tests
assert.strictEqual(classifyRisk(100), 'SAFE', '100% should be SAFE');
assert.strictEqual(classifyRisk(75.0), 'SAFE', '75.0% should be SAFE');
assert.strictEqual(classifyRisk(74.9), 'WARNING', '74.9% should be WARNING');
assert.strictEqual(classifyRisk(65.0), 'WARNING', '65.0% should be WARNING');
assert.strictEqual(classifyRisk(64.9), 'CRITICAL', '64.9% should be CRITICAL');
assert.strictEqual(classifyRisk(30.0), 'CRITICAL', '30.0% should be CRITICAL');
console.log('✓ All Risk Classifier tests passed.');

// 2. Recovery Estimator: Rahul Verma Demo Case (10 attended out of 16 classes)
const rahulAttended = 10;
const rahulTotal = 16;
const rahulPercentage = (rahulAttended / rahulTotal) * 100;
const rahulNeeded = calculateClassesNeeded(rahulAttended, rahulTotal);

console.log(`Rahul Verma: ${rahulAttended}/${rahulTotal} (${rahulPercentage.toFixed(1)}%) -> Classes Needed: ${rahulNeeded}`);
assert.strictEqual(rahulNeeded, 8, 'Rahul Verma (10/16) must need exactly 8 consecutive classes!');

// Verification: If Rahul attends 8 consecutive classes:
const newAttended = rahulAttended + 8;
const newTotal = rahulTotal + 8;
const newPercentage = (newAttended / newTotal) * 100;
assert.strictEqual(newAttended, 18);
assert.strictEqual(newTotal, 24);
assert.strictEqual(newPercentage, 75.0, 'Rahul should reach exactly 75.0% after 8 consecutive classes');
console.log(`✓ Rahul Verma recovery scenario verified: (10+8)/(16+8) = 18/24 = 75.0%!`);

// 3. Safe Student Bunk Allowance test
const safeAttended = 18;
const safeTotal = 20; // 90%
const safeNeeded = calculateClassesNeeded(safeAttended, safeTotal);
const safeBunk = calculateBunkAllowance(safeAttended, safeTotal);
assert.strictEqual(safeNeeded, 0, 'Safe student needs 0 recovery classes');
assert.strictEqual(safeBunk, 4, '90% student can miss 4 classes without dropping below 75%');
// Verification: If safe student misses 4 classes: 18 / 24 = 75.0%
assert.strictEqual(18 / (20 + 4), 0.75);
console.log(`✓ Safe student bunk allowance verified: 18/(20+4) = 75.0%`);

// 4. Pearson Correlation test
const xSample = [60, 70, 80, 90, 100];
const ySample = [55, 68, 79, 88, 98];
const r = calculatePearsonCorrelation(xSample, ySample);
assert.ok(r > 0.95, 'Linear relation should yield r > 0.95');
console.log(`✓ Pearson correlation test passed: r = ${r}`);

console.log('\n>>> ALL 4 CALCULATION TEST SUITES PASSED FLAWLESSLY! <<<');
