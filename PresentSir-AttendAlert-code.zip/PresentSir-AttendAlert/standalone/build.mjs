import fs from 'fs';
const SRC = process.argv[2], OUT = process.argv[3];
const rd = p => fs.readFileSync(`${SRC}/${p}`, 'utf-8');

const calc = rd('server/calc.js').replace(/^export /gm, '');
let db = rd('server/db.js');
db = db.slice(db.indexOf('class Database {'), db.indexOf('export const db'));

// routes: strip node-only setup, keep handlers
let routes = rd('server/routes.js');
routes = routes.slice(routes.indexOf('export const router'));
routes = routes.replace('export const router = express.Router();', 'const router = makeRouter();');
routes = routes.replace(/upload\.single\('[a-z]+'\), /g, '');
routes = routes.replace("const content = fs.readFileSync(req.file.path, 'utf-8');", 'const content = req.file.text;');
routes = routes.replace('/uploads/${req.file.filename}', '${req.file.url}');
routes = routes.replace("'/uploads/sample_medical_certificate.pdf'", "''");
if (/fs\.|path\./.test(routes)) throw new Error('node api left in routes');

const shim = `
(function(){
const SEED = JSON.parse(document.getElementById('seed-data').textContent);
${calc}
${db}
Database.prototype.init = function(){ this.data = JSON.parse(JSON.stringify(SEED)); this.rebuildCache(); };
Database.prototype.save = function(){};
Database.prototype.reset = function(){ this.data = JSON.parse(JSON.stringify(SEED)); this.rebuildCache(); };
const db = new Database();

function makeRouter(){
  const table = [];
  const add = method => (path, handler) => {
    const keys = [];
    const re = new RegExp('^' + path.replace(/:([A-Za-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    table.push({ method, re, keys, handler });
  };
  return { get: add('GET'), post: add('POST'), patch: add('PATCH'), table };
}
${routes}

function mockRes(resolve){
  let status = 200; const headers = {};
  const res = {
    status(c){ status = c; return res; },
    setHeader(k, v){ headers[k] = v; },
    json(o){ resolve(new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json' } })); },
    send(t){ resolve(new Response(t, { status, headers })); }
  };
  return res;
}

async function handle(url, init){
  const u = new URL(url, location.origin);
  const method = ((init && init.method) || 'GET').toUpperCase();
  const route = router.table.find(r => r.method === method && r.re.test(u.pathname.replace(/^\\/api/, '')));
  if (!route) return new Response(JSON.stringify({ success: false, error: 'Not found' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
  const m = u.pathname.replace(/^\\/api/, '').match(route.re);
  const params = {}; route.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1]));
  const query = Object.fromEntries(u.searchParams.entries());
  let body = {}, file;
  const b = init && init.body;
  if (typeof b === 'string') { try { body = JSON.parse(b); } catch { body = {}; } }
  else if (b instanceof FormData) {
    for (const [k, v] of b.entries()) {
      if (v instanceof File) {
        file = { originalname: v.name, url: URL.createObjectURL(v), text: await v.text() };
      } else body[k] = v;
    }
  }
  return new Promise(resolve => {
    try { route.handler({ params, query, body, file }, mockRes(resolve)); }
    catch (e) { resolve(new Response(JSON.stringify({ success: false, error: e.message }), { status: 500 })); }
  });
}

const realFetch = window.fetch.bind(window);
window.fetch = (input, init) => {
  const url = typeof input === 'string' ? input : input.url;
  if (/^\\/api\\//.test(url) || url.startsWith(location.origin + '/api/')) return handle(url, init);
  return realFetch(input, init);
};

// Anchor-based CSV export (was a server download)
document.addEventListener('click', async (e) => {
  const a = e.target.closest && e.target.closest('a[href="/api/roster/export-csv"]');
  if (!a) return;
  e.preventDefault();
  const res = await handle('/api/roster/export-csv', {});
  const blob = new Blob([await res.text()], { type: 'text/csv' });
  const l = document.createElement('a');
  l.href = URL.createObjectURL(blob); l.download = 'PresentSir_Attendance_Roster_Report.csv';
  document.body.appendChild(l); l.click(); l.remove();
}, true);
})();
`;

const js = rd('client/dist/assets/index-CQfOIaKw.js').replace(/<\/script/gi, '<\\/script');
const css = rd('client/dist/assets/index-BQUMrpwt.css');
const seed = fs.readFileSync(`${SRC}/data/database.json`, 'utf-8');
const seedMin = JSON.stringify(JSON.parse(seed)).replace(/</g, '\\u003c');
const fav = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#4f46e5"/><path d="M8 17l5 5 11-12" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>');

const html = `<title>PresentSir AttendAlert</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>${css}
a[href="/download-zip"]{display:none!important}
body{background:#0f172a}</style>
<div id="root"></div>
<script id="seed-data" type="application/json">${seedMin}</script>
<script>${shim}</script>
<script type="module">${js}</script>
`;
fs.writeFileSync(OUT, html);
console.log('bytes', html.length);
