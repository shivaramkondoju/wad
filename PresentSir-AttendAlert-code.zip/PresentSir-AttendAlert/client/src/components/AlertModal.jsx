import React, { useState } from 'react';
import { X, Mail, Send, AlertTriangle, ShieldAlert, CheckCircle2, Eye } from 'lucide-react';

export default function AlertModal({
  student,
  onClose,
  onSendAlert
}) {
  const [recipientType, setRecipientType] = useState('BOTH');
  const [customRemarks, setCustomRemarks] = useState(
    'Please contact Academic Mentor Prof. Dr. Arvind Menon immediately. Continued absence will result in semester examination hall ticket withholding.'
  );
  const [isSending, setIsSending] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  if (!student) return null;

  const handleSend = async (e) => {
    e.preventDefault();
    setIsSending(true);
    try {
      await onSendAlert({
        studentId: student.id,
        recipientType,
        customRemarks: customRemarks.trim()
      });
      onClose();
    } catch (err) {
      alert('Error dispatching alert: ' + err.message);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400">
              <Mail className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-400">
                  Automated Early-Warning Dispatch
                </span>
                <span className="text-xs text-slate-500">• Parent & Student Alert</span>
              </div>
              <h3 className="text-lg font-black text-white">
                Dispatch Detention Warning Notice
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Student Target Summary */}
        <div className="p-4 bg-rose-950/20 border-b border-rose-900/40 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-300 font-bold">{student.name}</span>
            <span className="text-slate-400 ml-1.5 font-mono">({student.rollNo})</span>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Attendance: <strong className="text-rose-400 font-mono">{student.overallPercentage}%</strong> • Deficit: <strong className="text-white font-mono">{student.overallClassesNeeded} classes</strong> needed
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPreviewMode(!previewMode)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition border border-slate-700"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>{previewMode ? 'Edit Options' : 'Preview Letter'}</span>
          </button>
        </div>

        {previewMode ? (
          /* Live Letter Preview */
          <div className="p-6 max-h-[420px] overflow-y-auto space-y-4">
            <div className="bg-white text-slate-900 p-6 rounded-2xl shadow-inner font-sans text-xs space-y-4 border border-slate-300">
              <div className="border-b-2 border-red-700 pb-3 text-center">
                <h3 className="text-base font-black uppercase text-red-700 tracking-wide">
                  Department of Computer Science & Engineering
                </h3>
                <p className="text-[11px] text-slate-600 font-semibold">
                  Academic Council • Statutory Attendance Detention Early-Warning Notice
                </p>
              </div>

              <div>
                <p className="font-bold">To: Parent / Guardian of {student.name}</p>
                <p className="text-slate-600">Email: {student.parentEmail} | Phone: {student.parentPhone}</p>
                <p className="text-slate-600">CC: {student.email} (Student)</p>
              </div>

              <p>
                This official early-warning communication is issued pursuant to University Regulation 14.2 regarding mandatory attendance thresholds. Your ward <strong>{student.name}</strong> (Roll No: <strong>{student.rollNo}</strong>) has accumulated an attendance percentage of <strong className="text-red-700">{student.overallPercentage}%</strong> in Semester {student.semester}.
              </p>

              <div className="bg-red-50 border border-red-200 p-3 rounded-lg">
                <p className="font-bold text-red-900 mb-1">MANDATORY RECOVERY REQUIREMENT:</p>
                <p className="text-red-800 font-mono text-[11px]">
                  Student must attend the next <strong>{student.overallClassesNeeded} consecutive upcoming lectures</strong> without absence to regain eligibility above the 75% examination threshold.
                </p>
              </div>

              <div className="space-y-1">
                <p className="font-bold">Subject Shortage Summary:</p>
                <ul className="list-disc pl-5 space-y-0.5 text-slate-700">
                  {student.subjectBreakdown.map(sub => (
                    <li key={sub.subjectId}>
                      {sub.code} - {sub.name}: <strong>{sub.percentage}%</strong> ({sub.riskTier})
                      {sub.classesNeeded > 0 ? ` — Requires ${sub.classesNeeded} consecutive classes` : ' — Eligible'}
                    </li>
                  ))}
                </ul>
              </div>

              <p className="italic text-slate-700">
                "{customRemarks}"
              </p>

              <div className="pt-4 border-t border-slate-200 flex justify-between items-end text-[10px] text-slate-500">
                <div>
                  <p className="font-bold text-slate-700">Issued by: AttendAlert Early-Warning Engine</p>
                  <p>Timestamp: {new Date().toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-slate-800">{student.mentorName}</p>
                  <p>Senior Academic Mentor & HOD</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Form Controls */
          <form onSubmit={handleSend} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Recipient(s)
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'BOTH', label: 'Parent & Student', sub: 'Recommended' },
                  { id: 'PARENT', label: 'Parent Only', sub: student.parentEmail },
                  { id: 'STUDENT', label: 'Student Only', sub: student.email }
                ].map(opt => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setRecipientType(opt.id)}
                    className={`p-3 rounded-xl border text-left transition ${
                      recipientType === opt.id
                        ? 'bg-rose-600/20 border-rose-500 text-white ring-1 ring-rose-500/30'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="text-xs font-bold text-white">{opt.label}</div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">{opt.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Recipients Summary
              </label>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1 text-slate-300 font-mono">
                <div>Student: <span className="text-white">{student.email}</span></div>
                <div>Parent: <span className="text-white">{student.parentEmail}</span> ({student.parentPhone})</div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Custom Mentor Guidance & Instructions
              </label>
              <textarea
                rows={3}
                value={customRemarks}
                onChange={(e) => setCustomRemarks(e.target.value)}
                required
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl p-3 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-rose-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSending}
                className="flex items-center space-x-2 px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
                <span>{isSending ? 'Dispatching Notice...' : 'Send Simulated Warning Notice'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
