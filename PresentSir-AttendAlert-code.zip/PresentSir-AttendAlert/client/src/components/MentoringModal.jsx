import React, { useState } from 'react';
import { X, MessageSquarePlus, Save, Calendar, UserCheck, CheckCircle2 } from 'lucide-react';

export default function MentoringModal({
  student,
  onClose,
  onSubmit
}) {
  const [mentorName, setMentorName] = useState('Prof. Dr. Arvind Menon');
  const [subjectId, setSubjectId] = useState(
    student?.criticalSubjectCount > 0
      ? student.subjectBreakdown.find(s => s.riskTier === 'CRITICAL')?.subjectId || 'ALL'
      : 'ALL'
  );
  const [interventionType, setInterventionType] = useState('One-on-One Counseling');
  const [counselingNotes, setCounselingNotes] = useState('');
  const [actionPlan, setActionPlan] = useState('');
  const [nextFollowUpDate, setNextFollowUpDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [status, setStatus] = useState('In Progress');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!student) return null;

  const currentSubjectObj = student.subjectBreakdown?.find(s => s.subjectId === subjectId);
  const relevantClassesNeeded = currentSubjectObj ? currentSubjectObj.classesNeeded : student.overallClassesNeeded;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!counselingNotes.trim()) {
      alert('Please enter mentoring counseling notes.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        studentId: student.id,
        studentName: student.name,
        rollNo: student.rollNo,
        mentorName,
        riskTierAtTime: student.overallRiskTier,
        currentPercentage: student.overallPercentage,
        subjectId,
        subjectName: currentSubjectObj ? currentSubjectObj.name : 'Overall Academics',
        classesNeeded: relevantClassesNeeded,
        interventionType,
        counselingNotes: counselingNotes.trim(),
        actionPlan: actionPlan.trim(),
        status,
        nextFollowUpDate
      });
      onClose();
    } catch (err) {
      alert('Error saving intervention: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400">
              <MessageSquarePlus className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-400">
                  Academic Mentoring Log
                </span>
                <span className="text-xs text-slate-500">• Early-Intervention</span>
              </div>
              <h3 className="text-lg font-black text-white">
                Log Counseling Intervention: {student.name} ({student.rollNo})
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Current Risk Snapshot */}
        <div className="px-6 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400">Current Standing: </span>
            <strong className="text-rose-400 font-mono">{student.overallPercentage}%</strong>
            <span className="text-slate-500 ml-2">({student.totalAttended}/{student.totalClasses} classes)</span>
          </div>
          <div>
            <span className="text-slate-400">Recovery Requirement: </span>
            <strong className="text-white font-mono">{relevantClassesNeeded} consecutive classes</strong>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Academic Mentor Name
              </label>
              <input
                type="text"
                value={mentorName}
                onChange={(e) => setMentorName(e.target.value)}
                required
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Targeted Deficit Subject
              </label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="ALL">All Subjects (Overall Attendance)</option>
                {student.subjectBreakdown.map(s => (
                  <option key={s.subjectId} value={s.subjectId}>
                    {s.code} - {s.name} ({s.percentage}%)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Intervention Modality
              </label>
              <select
                value={interventionType}
                onChange={(e) => setInterventionType(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="One-on-One Counseling">One-on-One Counseling Session</option>
                <option value="Parent Call">Telephonic Parent Conference</option>
                <option value="Attendance Contract Signed">Formal Attendance Recovery Contract</option>
                <option value="Academic Warning Notice">Official Dean's Warning Issued</option>
                <option value="Peer Study Group Assigned">Peer Study Buddy Assignment</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Next Follow-up Review Date
              </label>
              <input
                type="date"
                value={nextFollowUpDate}
                onChange={(e) => setNextFollowUpDate(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Counseling Notes & Root-Cause Discussion
            </label>
            <textarea
              rows={3}
              value={counselingNotes}
              onChange={(e) => setCounselingNotes(e.target.value)}
              placeholder="Record mentor discussion points, student reasons (e.g. transit delays, health recovery), and verbal commitments..."
              required
              className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl p-3 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder-slate-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Action Plan & Recovery Milestones
            </label>
            <textarea
              rows={2}
              value={actionPlan}
              onChange={(e) => setActionPlan(e.target.value)}
              placeholder="e.g. Student committed to attending next 8 consecutive classes without absence. Parent will monitor weekly attendance report."
              className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl p-3 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder-slate-500"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-400">Intervention Status:</span>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="bg-slate-950 text-purple-300 font-bold text-xs rounded-lg px-2.5 py-1 border border-slate-800 focus:outline-none"
              >
                <option value="Open">Open</option>
                <option value="In Progress">In Progress</option>
                <option value="Resolved">Resolved</option>
              </select>
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center space-x-2 px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition disabled:opacity-50"
              >
                <Save className="h-4 w-4" />
                <span>{isSubmitting ? 'Recording...' : 'Save Mentoring Record'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
