import React, { useState } from 'react';
import {
  X,
  TrendingUp,
  ShieldCheck,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  MessageSquarePlus,
  MailWarning,
  Sparkles,
  BookOpen,
  Award,
  Clock,
  History,
  FileHeart
} from 'lucide-react';

export default function StudentDetailModal({
  student,
  onClose,
  onLogMentoring,
  onSendAlert
}) {
  const [activeTab, setActiveTab] = useState('subjects'); // 'subjects' | 'history' | 'interventions' | 'simulator'
  const [simulateClasses, setSimulateClasses] = useState(8);

  if (!student) return null;

  const isCritical = student.overallRiskTier === 'CRITICAL' || student.criticalSubjectCount > 0;
  const isWarning = !isCritical && (student.overallRiskTier === 'WARNING' || student.warningSubjectCount > 0);

  // Recovery simulator calculation for overall attendance
  const simTotal = student.totalClasses + Number(simulateClasses);
  const simAttended = student.totalAttended + Number(simulateClasses);
  const simPercent = simTotal > 0 ? Number(((simAttended / simTotal) * 100).toFixed(1)) : 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header Bar */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-start justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className={`h-14 w-14 rounded-2xl flex items-center justify-center text-lg font-black shadow-lg ring-1 ${
              isCritical
                ? 'bg-rose-500/20 text-rose-300 ring-rose-500/40'
                : isWarning
                ? 'bg-amber-500/20 text-amber-300 ring-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 ring-emerald-500/40'
            }`}>
              {student.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center space-x-2.5">
                <h2 className="text-xl sm:text-2xl font-black text-white">{student.name}</h2>
                <span className="font-mono text-xs px-2.5 py-0.5 rounded-md bg-slate-800 text-slate-300 font-bold border border-slate-700">
                  {student.rollNo}
                </span>
                <span className={`px-2.5 py-0.5 rounded-md text-xs font-black uppercase border ${
                  isCritical
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                    : isWarning
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                }`}>
                  {student.overallRiskTier}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {student.department} • Semester {student.semester} - Section {student.section} • Mentor: {student.mentorName}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                Parent: <span className="text-slate-300">{student.parentEmail}</span> ({student.parentPhone})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Highlight Banner: Early Warning & Recovery Requirement */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Statutory 75% Eligibility Rule Standing
              </div>
              <div className="text-sm font-extrabold text-white">
                Overall: <span className={isCritical ? 'text-rose-400' : isWarning ? 'text-amber-400' : 'text-emerald-400'}>
                  {student.overallPercentage}%
                </span> ({student.totalAttended} / {student.totalClasses} classes)
                {student.overallClassesNeeded > 0 ? (
                  <span className="text-rose-300 font-bold ml-2">
                    — Must attend next <strong>{student.overallClassesNeeded} consecutive classes</strong> to regain eligibility
                  </span>
                ) : (
                  <span className="text-emerald-400 font-bold ml-2">
                    — Exam Eligible! Can miss up to <strong>{student.overallBunkAllowance} classes</strong> safely
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={() => onLogMentoring(student)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-md shadow-purple-600/30"
            >
              <MessageSquarePlus className="h-4 w-4" />
              <span>Log Mentoring Intervention</span>
            </button>

            <button
              onClick={() => onSendAlert(student)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-md shadow-rose-600/30"
            >
              <MailWarning className="h-4 w-4" />
              <span>Dispatch Warning Email</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 px-6 pt-4 border-b border-slate-800 bg-slate-900/40">
          {[
            { id: 'subjects', label: 'Subject Deficits & Recovery', icon: BookOpen },
            { id: 'simulator', label: 'What-If Recovery Simulator', icon: Sparkles },
            { id: 'history', label: 'Session Attendance Logs', icon: History },
            { id: 'interventions', label: `Counseling History (${student.interventions?.length || 0})`, icon: MessageSquarePlus }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2.5 border-b-2 text-xs font-bold transition ${
                  activeTab === tab.id
                    ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10 rounded-t-xl'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="p-6 max-h-[460px] overflow-y-auto">
          {/* TAB 1: SUBJECTS BREAKDOWN */}
          {activeTab === 'subjects' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {student.subjectBreakdown.map(sub => {
                  const subCritical = sub.riskTier === 'CRITICAL';
                  const subWarning = sub.riskTier === 'WARNING';

                  return (
                    <div
                      key={sub.subjectId}
                      className={`p-4 rounded-2xl border transition-all ${
                        subCritical
                          ? 'bg-rose-950/20 border-rose-900/50'
                          : subWarning
                          ? 'bg-amber-950/20 border-amber-900/50'
                          : 'bg-slate-950/50 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-mono text-xs font-bold text-slate-400">
                            {sub.code}
                          </span>
                          <h4 className="text-sm font-black text-white">{sub.name}</h4>
                          <p className="text-[11px] text-slate-400">{sub.facultyName}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[11px] font-extrabold border ${
                          subCritical
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                            : subWarning
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        }`}>
                          {sub.riskTier}
                        </span>
                      </div>

                      {/* Percentage & Progress Bar */}
                      <div className="mt-3 space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-mono font-bold text-white text-base">
                            {sub.percentage}%
                          </span>
                          <span className="text-slate-400 text-xs">
                            {sub.attended} attended / {sub.totalClasses} held
                            {sub.excusedCount > 0 && ` (${sub.excusedCount} medical excused)`}
                          </span>
                        </div>
                        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              subCritical ? 'bg-rose-500' :
                              subWarning ? 'bg-amber-500' : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(100, sub.percentage)}%` }}
                          />
                        </div>
                      </div>

                      {/* Recovery Estimate Alert Box */}
                      <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                        {sub.classesNeeded > 0 ? (
                          <div className="flex items-center space-x-1.5 text-rose-300 font-medium">
                            <TrendingUp className="h-4 w-4 text-rose-400 shrink-0" />
                            <span>
                              Must attend next <strong className="text-white text-sm">{sub.classesNeeded}</strong> consecutive classes without absence
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-1.5 text-emerald-400">
                            <ShieldCheck className="h-4 w-4 shrink-0" />
                            <span>
                              Safe to miss <strong className="text-white text-sm">{sub.bunkAllowance}</strong> classes before hitting 75%
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: WHAT-IF RECOVERY SIMULATOR */}
          {activeTab === 'simulator' && (
            <div className="p-5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-5">
              <div>
                <h3 className="text-base font-black text-white flex items-center space-x-2">
                  <Sparkles className="h-5 w-5 text-indigo-400" />
                  <span>Closed-Form Recovery Projection Simulator</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Adjust the slider to simulate attending upcoming consecutive lectures. Observe dynamic percentage growth computed with formula: <code>(Attended + x) / (Total + x) ≥ 0.75</code>.
                </p>
              </div>

              {/* Interactive Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-300">Upcoming Consecutive Classes Attended:</span>
                  <span className="text-lg font-black text-indigo-400 font-mono">
                    +{simulateClasses} Classes
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={simulateClasses}
                  onChange={(e) => setSimulateClasses(Number(e.target.value))}
                  className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>0 (No recovery)</span>
                  <span>5 classes</span>
                  <span>10 classes</span>
                  <span>15 classes</span>
                  <span>20 classes</span>
                </div>
              </div>

              {/* Simulation Result Box */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-[11px] text-slate-400 uppercase font-semibold">Current Standing</div>
                  <div className="text-xl font-mono font-bold text-slate-300 mt-1">{student.overallPercentage}%</div>
                  <div className="text-xs text-slate-500">{student.totalAttended}/{student.totalClasses}</div>
                </div>

                <div className="sm:border-x border-slate-800">
                  <div className="text-[11px] text-slate-400 uppercase font-semibold">Projected Standing</div>
                  <div className={`text-2xl font-mono font-black mt-1 ${
                    simPercent >= 75 ? 'text-emerald-400' : simPercent >= 65 ? 'text-amber-400' : 'text-rose-400'
                  }`}>
                    {simPercent}%
                  </div>
                  <div className="text-xs text-slate-500">{simAttended}/{simTotal} total</div>
                </div>

                <div>
                  <div className="text-[11px] text-slate-400 uppercase font-semibold">Eligibility Forecast</div>
                  <div className="mt-1">
                    {simPercent >= 75 ? (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-black border border-emerald-500/30">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>ELIGIBLE FOR EXAMS</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 text-xs font-black border border-rose-500/30">
                        <AlertOctagon className="h-4 w-4" />
                        <span>STILL DETAINED ({Math.ceil((0.75 * simTotal - simAttended) / 0.25)} more needed)</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ATTENDANCE SESSION HISTORY */}
          {activeTab === 'history' && (
            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-4">Date & Time</th>
                    <th className="py-2.5 px-4">Subject</th>
                    <th className="py-2.5 px-4">Topic Covered</th>
                    <th className="py-2.5 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                  {student.attendanceHistory?.slice(0, 20).map(rec => (
                    <tr key={rec.id} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-4 font-mono text-slate-300">
                        {rec.date} <span className="text-slate-500">({rec.slot})</span>
                      </td>
                      <td className="py-2.5 px-4 font-bold text-white">
                        {rec.subjectCode}
                      </td>
                      <td className="py-2.5 px-4 text-slate-300 max-w-xs truncate">
                        {rec.topic}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          rec.status === 'PRESENT'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : rec.status === 'LATE'
                            ? 'bg-amber-500/20 text-amber-300'
                            : rec.status === 'EXCUSED'
                            ? 'bg-cyan-500/20 text-cyan-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}>
                          {rec.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB 4: COUNSELING INTERVENTIONS */}
          {activeTab === 'interventions' && (
            <div className="space-y-3">
              {student.interventions?.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No mentoring counseling sessions logged yet for this student.
                </div>
              ) : (
                student.interventions?.map(item => (
                  <div key={item.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">{item.interventionType}</span>
                      <span className="text-slate-400">{new Date(item.date).toLocaleDateString()}</span>
                    </div>
                    <p className="text-xs text-slate-300">
                      <strong>Notes:</strong> {item.counselingNotes}
                    </p>
                    {item.actionPlan && (
                      <p className="text-xs text-indigo-300">
                        <strong>Action Plan:</strong> {item.actionPlan}
                      </p>
                    )}
                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                      <span>Mentor: {item.mentorName}</span>
                      <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                        {item.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
