import React from 'react';
import {
  Users,
  Percent,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  FileHeart,
  MessageSquare
} from 'lucide-react';

export default function OverviewCards({
  overview,
  activeFilter,
  onSelectFilter,
  onOpenMedical,
  onOpenMentoringList
}) {
  const cards = [
    {
      id: 'ALL',
      title: 'Enrolled Students',
      value: overview?.totalStudents || 30,
      subtext: `${overview?.totalSubjects || 5} Core Subjects • 4 Weeks`,
      icon: Users,
      color: 'indigo',
      borderClass: 'border-slate-800 hover:border-indigo-500/50',
      bgClass: 'bg-slate-800/40'
    },
    {
      id: 'AVG',
      title: 'Batch Attendance',
      value: `${overview?.avgAttendance || 78.1}%`,
      subtext: 'Class Average vs 75% Cutoff',
      icon: Percent,
      color: overview?.avgAttendance >= 75 ? 'emerald' : 'amber',
      borderClass: 'border-slate-800',
      bgClass: 'bg-slate-800/40'
    },
    {
      id: 'CRITICAL',
      title: 'Critical Tier (<65%)',
      value: overview?.criticalCount || 0,
      subtext: 'Hall Ticket Withheld Risk',
      icon: AlertOctagon,
      color: 'rose',
      borderClass: activeFilter === 'CRITICAL' ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-rose-900/40 hover:border-rose-500/50',
      bgClass: 'bg-rose-950/20',
      clickable: true
    },
    {
      id: 'WARNING',
      title: 'Warning Tier (65-74%)',
      value: overview?.warningCount || 0,
      subtext: 'Borderline Shortage',
      icon: AlertTriangle,
      color: 'amber',
      borderClass: activeFilter === 'WARNING' ? 'border-amber-500 ring-2 ring-amber-500/20' : 'border-amber-900/40 hover:border-amber-500/50',
      bgClass: 'bg-amber-950/20',
      clickable: true
    },
    {
      id: 'SAFE',
      title: 'Safe Standing (≥75%)',
      value: overview?.safeCount || 0,
      subtext: 'Statutory Exam Eligible',
      icon: CheckCircle2,
      color: 'emerald',
      borderClass: activeFilter === 'SAFE' ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-emerald-900/40 hover:border-emerald-500/50',
      bgClass: 'bg-emerald-950/20',
      clickable: true
    },
    {
      id: 'MEDICAL',
      title: 'Medical Condonations',
      value: overview?.pendingMedicalCount || 0,
      subtext: 'Pending Doctor Verification',
      icon: FileHeart,
      color: 'cyan',
      borderClass: 'border-slate-800 hover:border-cyan-500/50',
      bgClass: 'bg-cyan-950/10',
      clickable: true,
      onClick: onOpenMedical
    },
    {
      id: 'MENTORING',
      title: 'Active Interventions',
      value: overview?.openInterventionsCount || 0,
      subtext: 'Open Counseling Cases',
      icon: MessageSquare,
      color: 'purple',
      borderClass: 'border-slate-800 hover:border-purple-500/50',
      bgClass: 'bg-purple-950/10',
      clickable: true,
      onClick: onOpenMentoringList
    }
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 sm:gap-4">
      {cards.map(card => {
        const Icon = card.icon;
        const isFilterActive = activeFilter === card.id;

        return (
          <div
            key={card.id}
            onClick={() => {
              if (card.onClick) {
                card.onClick();
              } else if (card.clickable && onSelectFilter) {
                onSelectFilter(card.id);
              }
            }}
            className={`rounded-2xl p-4 border transition-all relative overflow-hidden ${card.bgClass} ${card.borderClass} ${
              card.clickable ? 'cursor-pointer transform hover:-translate-y-0.5 hover:shadow-lg' : ''
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                {card.title}
              </span>
              <div className={`p-1.5 rounded-lg ${
                card.color === 'rose' ? 'bg-rose-500/20 text-rose-400' :
                card.color === 'amber' ? 'bg-amber-500/20 text-amber-400' :
                card.color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400' :
                card.color === 'cyan' ? 'bg-cyan-500/20 text-cyan-400' :
                card.color === 'purple' ? 'bg-purple-500/20 text-purple-400' :
                'bg-indigo-500/20 text-indigo-400'
              }`}>
                <Icon className="h-4 w-4" />
              </div>
            </div>

            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black text-white tracking-tight">
                {card.value}
              </span>
            </div>

            <p className="text-[11px] text-slate-400 mt-1 truncate">
              {card.subtext}
            </p>

            {isFilterActive && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 to-rose-500" />
            )}
          </div>
        );
      })}
    </div>
  );
}
