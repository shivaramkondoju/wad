import React, { useState } from 'react';
import { X, Mail, ShieldAlert, CheckCircle2, Clock, Send, Eye } from 'lucide-react';

export default function AlertHistoryDrawer({ alerts, onClose }) {
  const [selectedAlert, setSelectedAlert] = useState(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400">
              <Mail className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-rose-400">
                Automated Notification Outbox & Audit Trail
              </div>
              <h3 className="text-lg font-black text-white">
                Dispatched Warning Notices ({alerts?.length || 0})
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[500px] overflow-y-auto space-y-4">
          {alerts?.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No simulated warning notices dispatched yet.
            </div>
          ) : (
            alerts.map(a => (
              <div
                key={a.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-extrabold text-white text-sm">{a.studentName}</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {a.rollNo}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300">
                      {a.riskTier} ({a.attendancePercent}%)
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {new Date(a.sentAt).toLocaleString()}
                  </span>
                </div>

                <div className="text-xs text-slate-300">
                  <span className="text-slate-400 font-semibold">Subject: </span>
                  {a.subject}
                </div>

                <div className="text-[11px] text-slate-400 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800/80 font-mono">
                  {a.bodySnippet}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                  <span>Recipients: <strong className="text-slate-300">{a.studentEmail}</strong> & <strong className="text-slate-300">{a.parentEmail}</strong></span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                    {a.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
