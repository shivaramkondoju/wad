import React from 'react';
import { AlertTriangle, ArrowRight, ShieldAlert, Sparkles, BellRing } from 'lucide-react';

export default function CriticalBanner({
  criticalCount,
  onFilterCritical,
  onQuickInspectStudent,
  rahulVerma
}) {
  if (criticalCount === 0) return null;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-rose-950/80 via-red-900/60 to-slate-900 border-2 border-rose-500/40 p-4 sm:p-5 shadow-2xl shadow-rose-950/50 backdrop-blur-md">
      {/* Decorative Glow */}
      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center space-x-3.5">
          <div className="p-2.5 bg-rose-500/20 text-rose-400 rounded-xl border border-rose-500/30 shrink-0 animate-pulse">
            <BellRing className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 text-xs font-black uppercase tracking-wider rounded-md bg-rose-500 text-white">
                STATUTORY CRITICAL SHORTAGE
              </span>
              <span className="text-xs text-rose-300 font-medium hidden sm:inline">
                Semester Exam Detention Risk
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-extrabold text-white mt-1">
              {criticalCount} Students in Critical Shortage (&lt;65%)
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Cumulative attendance is below mandatory condonation thresholds. Mentors must initiate immediate intervention counseling before semester hall tickets are withheld.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center flex-wrap gap-2.5 w-full md:w-auto">
          {/* Quick Demo Highlight Button for Rahul Verma */}
          {rahulVerma && (
            <button
              onClick={() => onQuickInspectStudent(rahulVerma)}
              className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 transition transform hover:-translate-y-0.5"
            >
              <Sparkles className="h-4 w-4 text-amber-300" />
              <span>Inspect Rahul Verma (62% in DSA)</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}

          <button
            onClick={onFilterCritical}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-semibold transition"
          >
            <span>Filter All At-Risk</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
