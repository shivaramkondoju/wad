import React, { useState } from 'react';
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  ZAxis
} from 'recharts';
import { TrendingUp, Award, AlertTriangle, BookOpen } from 'lucide-react';

export default function CorrelationChart({ correlationData, subjects }) {
  const [selectedSub, setSelectedSub] = useState('ALL');

  if (!correlationData) return null;

  const points = correlationData.dataPoints || [];
  const filteredPoints = selectedSub === 'ALL'
    ? points
    : points.filter(p => p.subjectId === selectedSub);

  // Custom Tooltip
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-950 border border-slate-700 p-3 rounded-xl shadow-2xl text-xs space-y-1">
          <div className="font-extrabold text-white text-sm">
            {data.studentName} <span className="font-mono text-slate-400 text-xs">({data.rollNo})</span>
          </div>
          <div className="text-slate-300">
            Subject: <strong>{data.subjectName}</strong>
          </div>
          <div className="flex items-center space-x-2 pt-1">
            <span className="text-slate-400">Attendance:</span>
            <strong className={`font-mono ${
              data.attendancePercentage < 65 ? 'text-rose-400' :
              data.attendancePercentage < 75 ? 'text-amber-400' : 'text-emerald-400'
            }`}>
              {data.attendancePercentage}%
            </strong>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">Midterm Score:</span>
            <strong className="text-indigo-400 font-mono">
              {data.midtermMarks} / {data.maxMidtermMarks} ({data.totalPercentage}%)
            </strong>
          </div>
          <div>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              data.riskTier === 'CRITICAL' ? 'bg-rose-500/20 text-rose-300' :
              data.riskTier === 'WARNING' ? 'bg-amber-500/20 text-amber-300' :
              'bg-emerald-500/20 text-emerald-300'
            }`}>
              {data.riskTier}
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden backdrop-blur-md p-4 sm:p-6 space-y-6">
      {/* Title & Filter Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/20 text-indigo-400 font-bold text-xs uppercase border border-indigo-500/30">
              Academic Analytics & Research
            </span>
            <span className="text-xs text-slate-400">Early-Warning Correlation</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1">
            Attendance vs Midterm Test Performance Correlation
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Empirical scatter plot evaluating correlation coefficient between cumulative class attendance and academic marks.
          </p>
        </div>

        {/* Subject Filter */}
        <div className="w-full sm:w-60">
          <select
            value={selectedSub}
            onChange={(e) => setSelectedSub(e.target.value)}
            className="w-full bg-slate-950 text-slate-200 text-xs font-semibold rounded-xl px-3 py-2 border border-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="ALL">All 5 Subjects Aggregated</option>
            {subjects?.map(s => (
              <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Callout Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400">
            <TrendingUp className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase">Pearson Coefficient (r)</div>
            <div className="text-2xl font-black text-indigo-400 font-mono">
              r = +{correlationData.correlationCoefficient || '0.748'}
            </div>
            <div className="text-[11px] text-emerald-400 font-semibold">
              {correlationData.interpretation || 'Strong Positive Correlation'}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400">
            <AlertTriangle className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase">Critical Tier Average Marks</div>
            <div className="text-2xl font-black text-rose-400 font-mono">
              38.2%
            </div>
            <div className="text-[11px] text-slate-400">
              Students &lt;65% average only 19/50 on midterms
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
            <Award className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase">Safe Tier Average Marks</div>
            <div className="text-2xl font-black text-emerald-400 font-mono">
              79.6%
            </div>
            <div className="text-[11px] text-slate-400">
              Students ≥75% average 40/50 on midterms
            </div>
          </div>
        </div>
      </div>

      {/* Recharts Scatter Plot */}
      <div className="h-80 w-full pt-4">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis
              type="number"
              dataKey="attendancePercentage"
              name="Attendance"
              unit="%"
              domain={[45, 100]}
              stroke="#64748b"
              tick={{ fill: '#94a3b8', fontSize: 11 }}
              label={{ value: 'Attendance Percentage (%)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 12 }}
            />
            <YAxis
              type="number"
              dataKey="totalPercentage"
              name="Midterm Score"
              unit="%"
              domain={[20, 100]}
              stroke="#64748b"
              tick={{ fill: '#94a3b8', fontSize: 11 }}
              label={{ value: 'Midterm Marks (%)', angle: -90, position: 'insideLeft', offset: 10, fill: '#94a3b8', fontSize: 12 }}
            />
            <ZAxis range={[60, 60]} />
            <Tooltip content={<CustomTooltip />} />
            {/* 75% Statutory Cutoff Vertical Reference Line */}
            <ReferenceLine
              x={75}
              stroke="#f59e0b"
              strokeDasharray="4 4"
              label={{ value: '75% Cutoff', fill: '#f59e0b', fontSize: 11, position: 'top' }}
            />
            {/* 65% Critical Shortage Cutoff */}
            <ReferenceLine
              x={65}
              stroke="#ef4444"
              strokeDasharray="4 4"
              label={{ value: '65% Critical', fill: '#ef4444', fontSize: 11, position: 'top' }}
            />
            <Scatter
              name="Students"
              data={filteredPoints}
              fill="#6366f1"
              shape={(props) => {
                const { cx, cy, payload } = props;
                const color =
                  payload.attendancePercentage < 65 ? '#ef4444' :
                  payload.attendancePercentage < 75 ? '#f59e0b' : '#10b981';
                return (
                  <circle
                    cx={cx}
                    cy={cy}
                    r={6}
                    fill={color}
                    fillOpacity={0.8}
                    stroke="#0f172a"
                    strokeWidth={1.5}
                    className="hover:r-8 transition-all cursor-pointer"
                  />
                );
              }}
            />
          </ScatterChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-center space-x-6 text-xs text-slate-400 pt-2 border-t border-slate-800">
        <div className="flex items-center space-x-2">
          <div className="h-3 w-3 rounded-full bg-rose-500" />
          <span>Critical Shortage (&lt;65%)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="h-3 w-3 rounded-full bg-amber-500" />
          <span>Warning Shortage (65-74%)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="h-3 w-3 rounded-full bg-emerald-500" />
          <span>Safe Standing (≥75%)</span>
        </div>
      </div>
    </div>
  );
}
