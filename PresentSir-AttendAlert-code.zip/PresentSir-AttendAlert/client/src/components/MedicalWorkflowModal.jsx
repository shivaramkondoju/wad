import React, { useState } from 'react';
import { X, FileHeart, CheckCircle2, XCircle, FileText, Clock, Hospital, UserCheck } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function MedicalWorkflowModal({
  medicalRequests,
  onClose,
  onReviewRequest
}) {
  const [remarks, setRemarks] = useState({});
  const [reviewingId, setReviewingId] = useState(null);

  const handleReview = async (id, status) => {
    setReviewingId(id);
    try {
      await onReviewRequest(id, {
        status,
        remarks: remarks[id] || (status === 'APPROVED' ? 'Medical certificate verified by department mentor.' : 'Insufficient medical documentation.')
      });
      if (status === 'APPROVED') {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 }
        });
      }
    } catch (err) {
      alert('Error reviewing medical exemption: ' + err.message);
    } finally {
      setReviewingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
              <FileHeart className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Medical Leave Exemption & Condonation Workflow
                </span>
              </div>
              <h3 className="text-lg font-black text-white">
                Faculty Medical Clearance & Recalculation Hub
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="px-6 py-3 bg-emerald-950/20 border-b border-emerald-900/40 text-xs text-emerald-300 flex items-center space-x-2">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>
            Approving a medical exemption automatically recalculates the student's attendance records to <strong>EXCUSED</strong> with full condonation credit!
          </span>
        </div>

        {/* Requests List */}
        <div className="p-6 max-h-[500px] overflow-y-auto space-y-4">
          {medicalRequests?.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No medical leave exemption requests submitted yet.
            </div>
          ) : (
            medicalRequests.map(req => {
              const isPending = req.status === 'PENDING';
              const isApproved = req.status === 'APPROVED';

              return (
                <div
                  key={req.id}
                  className={`p-5 rounded-2xl border transition-all ${
                    isPending
                      ? 'bg-slate-950 border-amber-500/40 shadow-lg'
                      : isApproved
                      ? 'bg-emerald-950/10 border-emerald-900/40'
                      : 'bg-rose-950/10 border-rose-900/40'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-extrabold text-white text-base">
                          {req.studentName}
                        </span>
                        <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          {req.rollNo}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${
                          isPending
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                            : isApproved
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        }`}>
                          {req.status}
                        </span>
                      </div>

                      <div className="mt-2 text-xs space-y-1 text-slate-300">
                        <div>
                          <strong>Reason:</strong> {req.reason}
                        </div>
                        <div className="flex items-center space-x-2 text-slate-400">
                          <Hospital className="h-3.5 w-3.5 text-slate-500" />
                          <span>{req.hospital} • {req.doctorName}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-slate-400">
                          <Clock className="h-3.5 w-3.5 text-slate-500" />
                          <span>Dates: <strong className="text-slate-200">{req.startDate} to {req.endDate}</strong> ({req.sessionsAffectedCount} lectures affected)</span>
                        </div>
                      </div>
                    </div>

                    {/* Certificate Attachment Pill */}
                    <div className="shrink-0">
                      <div className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-indigo-300">
                        <FileText className="h-4 w-4" />
                        <span>Medical_Cert.pdf</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions or Review Result */}
                  {isPending ? (
                    <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                      <input
                        type="text"
                        placeholder="Mentor review notes / hospital verification..."
                        value={remarks[req.id] || ''}
                        onChange={(e) => setRemarks({ ...remarks, [req.id]: e.target.value })}
                        className="w-full sm:w-2/3 bg-slate-900 text-slate-200 text-xs rounded-xl px-3 py-1.5 border border-slate-800 focus:outline-none"
                      />
                      <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
                        <button
                          type="button"
                          onClick={() => handleReview(req.id, 'REJECTED')}
                          disabled={reviewingId === req.id}
                          className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold transition disabled:opacity-50"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          <span>Reject</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleReview(req.id, 'APPROVED')}
                          disabled={reviewingId === req.id}
                          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/30 transition disabled:opacity-50"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Approve & Condonate</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
                      <span>Reviewed by: <strong>{req.reviewedBy}</strong> ({new Date(req.reviewedAt).toLocaleDateString()})</span>
                      <span className="italic">{req.remarks}</span>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
