import React, { useState } from 'react';
import {
  TrendingUp,
  ShieldCheck,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  BookOpen,
  Sparkles,
  FileHeart,
  Upload,
  History,
  Send,
  HelpCircle,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function StudentPortal({
  student,
  onSubmitMedical,
  onRefreshStudent
}) {
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'simulator' | 'medical' | 'history'
  const [targetGoal, setTargetGoal] = useState(75); // Target 75% or 80%
  const [medicalForm, setMedicalForm] = useState({
    startDate: '2026-11-12',
    endDate: '2026-11-14',
    sessionsAffectedCount: 3,
    reason: 'Severe Viral Bronchitis & High Fever',
    doctorName: 'Dr. S. K. Roy, MD',
    hospital: 'Fortis Memorial Hospital',
    remarks: 'Medical certificate and prescription attached'
  });
  const [isSubmittingMedical, setIsSubmittingMedical] = useState(false);

  if (!student) return null;

  const isCritical = student.overallRiskTier === 'CRITICAL' || student.criticalSubjectCount > 0;
  const isWarning = !isCritical && (student.overallRiskTier === 'WARNING' || student.warningSubjectCount > 0);

  // Closed-form calculation for custom target goal
  const goalDecimal = targetGoal / 100;
  const customNeeded = Math.max(
    0,
    Math.ceil(((goalDecimal * student.totalClasses) - student.totalAttended) / (1 - goalDecimal))
  );

  const handleMedicalSubmit = async (e) => {
    e.preventDefault();
    setIsSubmittingMedical(true);
    try {
      const formData = new FormData();
      formData.append('studentId', student.id);
      formData.append('startDate', medicalForm.startDate);
      formData.append('endDate', medicalForm.endDate);
      formData.append('sessionsAffectedCount', medicalForm.sessionsAffectedCount);
      formData.append('reason', medicalForm.reason);
      formData.append('doctorName', medicalForm.doctorName);
      formData.append('hospital', medicalForm.hospital);
      formData.append('remarks', medicalForm.remarks);

      await onSubmitMedical(formData);
      confetti({
        particleCount: 50,
        spread: 50,
        origin: { y: 0.6 }
      });
      alert('Medical exemption application submitted successfully for Academic Mentor review!');
      setActiveTab('overview');
      if (onRefreshStudent) onRefreshStudent();
    } catch (err) {
      alert('Error submitting medical application: ' + err.message);
    } finally {
      setIsSubmittingMedical(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 shadow-xl backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className={`h-16 w-16 rounded-2xl flex items-center justify-center text-xl font-black shadow-lg ${
              isCritical
                ? 'bg-rose-500/20 text-rose-300 ring-2 ring-rose-500/40'
                : isWarning
                ? 'bg-amber-500/20 text-amber-300 ring-2 ring-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 ring-2 ring-emerald-500/40'
            }`}>
              {student.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center space-x-2.5">
                <h1 className="text-2xl font-black text-white">{student.name}</h1>
                <span className="font-mono text-xs px-2.5 py-0.5 rounded-md bg-slate-800 text-slate-300 font-bold border border-slate-700">
                  {student.rollNo}
                </span>
                <span className={`px-2.5 py-0.5 rounded-md text-xs font-black uppercase border ${
                  isCritical
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                    : isWarning
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                }`}>
                  {student.overallRiskTier} TIER
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {student.department} • Semester {student.semester} - Section {student.section}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                Academic Mentor: <strong className="text-slate-200">{student.mentorName}</strong>
              </p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center space-x-3 bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
            <div className="text-center px-3">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Overall Attendance</div>
              <div className={`text-2xl font-black font-mono ${
                isCritical ? 'text-rose-400' : isWarning ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {student.overallPercentage}%
              </div>
            </div>
            <div className="border-l border-slate-800 pl-3 text-center px-3">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Attended</div>
              <div className="text-2xl font-black text-white font-mono">
                {student.totalAttended}/{student.totalClasses}
              </div>
            </div>
            <div className="border-l border-slate-800 pl-3 text-center px-3">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Statutory Target</div>
              <div className="text-2xl font-black text-indigo-400 font-mono">75.0%</div>
            </div>
          </div>
        </div>

        {/* Urgent Action Alert Bar */}
        {student.overallClassesNeeded > 0 ? (
          <div className="mt-5 p-4 rounded-2xl bg-rose-950/30 border border-rose-500/40 flex items-start sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400 shrink-0">
                <AlertOctagon className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-sm font-black text-white">
                  Examination Hall Ticket at Risk (Attendance Shortage)
                </h4>
                <p className="text-xs text-rose-300 mt-0.5">
                  You are below the 75% university requirement. You must attend the next{' '}
                  <strong className="text-white underline font-bold">{student.overallClassesNeeded} consecutive classes</strong>{' '}
                  without absence to regain exam eligibility.
                </p>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('simulator')}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shrink-0 transition"
            >
              Simulate Recovery
            </button>
          </div>
        ) : (
          <div className="mt-5 p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-sm font-black text-white">
                  Eligible for Semester Examination Hall Ticket
                </h4>
                <p className="text-xs text-emerald-300 mt-0.5">
                  Your attendance is in the Safe Tier. You can safely afford to miss up to{' '}
                  <strong className="text-white">{student.overallBunkAllowance} classes</strong> while remaining above 75%.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800">
        {[
          { id: 'overview', label: 'My Subjects Standing', icon: BookOpen },
          { id: 'simulator', label: 'Recovery & Goal Calculator', icon: Sparkles },
          { id: 'medical', label: 'Medical Leave Exemption', icon: FileHeart },
          { id: 'history', label: 'Attendance History Logs', icon: History }
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === tab.id
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: SUBJECTS OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {student.subjectBreakdown.map(sub => {
            const isSubCritical = sub.riskTier === 'CRITICAL';
            const isSubWarning = sub.riskTier === 'WARNING';

            return (
              <div
                key={sub.subjectId}
                className={`p-5 rounded-2xl border transition-all ${
                  isSubCritical
                    ? 'bg-rose-950/20 border-rose-900/60'
                    : isSubWarning
                    ? 'bg-amber-950/20 border-amber-900/60'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-400">
                    {sub.code}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${
                    isSubCritical
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      : isSubWarning
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  }`}>
                    {sub.riskTier}
                  </span>
                </div>

                <h3 className="text-base font-black text-white mt-1">{sub.name}</h3>
                <p className="text-xs text-slate-400">{sub.facultyName}</p>

                {/* Meter */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-2xl font-black font-mono text-white">{sub.percentage}%</span>
                    <span className="text-slate-400">
                      {sub.attended} / {sub.totalClasses} classes
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isSubCritical ? 'bg-rose-500' :
                        isSubWarning ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, sub.percentage)}%` }}
                    />
                  </div>
                </div>

                {/* Bottom Recovery Info */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 text-xs">
                  {sub.classesNeeded > 0 ? (
                    <div className="flex items-center space-x-1.5 text-rose-300 font-semibold">
                      <TrendingUp className="h-4 w-4 text-rose-400 shrink-0" />
                      <span>
                        Attend next <strong className="text-white text-sm">{sub.classesNeeded}</strong> consecutive classes
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-1.5 text-emerald-400">
                      <ShieldCheck className="h-4 w-4 shrink-0" />
                      <span>
                        Can miss <strong className="text-white text-sm">{sub.bunkAllowance}</strong> classes safely
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 2: RECOVERY CALCULATOR */}
      {activeTab === 'simulator' && (
        <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 space-y-6">
          <div>
            <h3 className="text-lg font-black text-white flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-amber-400" />
              <span>Personalized Recovery & Goal Estimator</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Set your target attendance percentage (75% minimum, or 80% / 85% for academic honors) and see the exact attendance roadmap required.
            </p>
          </div>

          {/* Goal Selector */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center space-x-4">
            <span className="text-xs font-bold text-slate-300">Target Attendance Goal:</span>
            {[75, 80, 85, 90].map(goal => (
              <button
                key={goal}
                type="button"
                onClick={() => setTargetGoal(goal)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition ${
                  targetGoal === goal
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {goal}% Goal
              </button>
            ))}
          </div>

          {/* Math Output Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-tr from-slate-950 to-slate-900 border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-xs text-slate-400 uppercase font-semibold">Current Overall</div>
              <div className="text-3xl font-black font-mono text-white mt-1">
                {student.overallPercentage}%
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {student.totalAttended} / {student.totalClasses} classes attended
              </div>
            </div>

            <div className="md:border-x border-slate-800">
              <div className="text-xs text-slate-400 uppercase font-semibold">Classes Needed for {targetGoal}%</div>
              <div className="text-4xl font-black font-mono text-amber-400 mt-1">
                {customNeeded}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Consecutive upcoming lectures without absence
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400 uppercase font-semibold">After Recovery</div>
              <div className="text-3xl font-black font-mono text-emerald-400 mt-1">
                {targetGoal}.0%
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {student.totalAttended + customNeeded} / {student.totalClasses + customNeeded} total classes
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MEDICAL APPLICATION */}
      {activeTab === 'medical' && (
        <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 space-y-6">
          <div>
            <h3 className="text-lg font-black text-white flex items-center space-x-2">
              <FileHeart className="h-5 w-5 text-emerald-400" />
              <span>Submit Medical Leave Exemption Application</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Upload doctor certificate and hospital discharge documents. Upon mentor approval, affected absence sessions are converted to <strong>EXCUSED</strong> condonation!
            </p>
          </div>

          <form onSubmit={handleMedicalSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Leave Start Date
                </label>
                <input
                  type="date"
                  value={medicalForm.startDate}
                  onChange={(e) => setMedicalForm({ ...medicalForm, startDate: e.target.value })}
                  required
                  className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Leave End Date
                </label>
                <input
                  type="date"
                  value={medicalForm.endDate}
                  onChange={(e) => setMedicalForm({ ...medicalForm, endDate: e.target.value })}
                  required
                  className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Hospital / Clinic Name
                </label>
                <input
                  type="text"
                  value={medicalForm.hospital}
                  onChange={(e) => setMedicalForm({ ...medicalForm, hospital: e.target.value })}
                  required
                  className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Attending Doctor & Qualification
                </label>
                <input
                  type="text"
                  value={medicalForm.doctorName}
                  onChange={(e) => setMedicalForm({ ...medicalForm, doctorName: e.target.value })}
                  required
                  className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Medical Diagnosis & Reason
              </label>
              <textarea
                rows={2}
                value={medicalForm.reason}
                onChange={(e) => setMedicalForm({ ...medicalForm, reason: e.target.value })}
                required
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl p-3 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="p-4 border-2 border-dashed border-slate-700 rounded-2xl bg-slate-950 text-center space-y-2">
              <Upload className="h-6 w-6 text-slate-400 mx-auto" />
              <div className="text-xs text-slate-300">
                Medical Certificate PDF / Scan Attached (mock_certificate_STU001.pdf)
              </div>
              <p className="text-[10px] text-slate-500">
                Hospital discharge summary, diagnostic reports & doctor prescription
              </p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSubmittingMedical}
                className="flex items-center space-x-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 transition disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
                <span>{isSubmittingMedical ? 'Submitting Application...' : 'Submit Exemption Request'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 4: ATTENDANCE HISTORY LOGS */}
      {activeTab === 'history' && (
        <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 space-y-4">
          <h3 className="text-lg font-black text-white">Recent Session Logs</h3>
          <div className="border border-slate-800 rounded-xl overflow-hidden max-h-[400px] overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-[11px] font-bold text-slate-400 uppercase tracking-wider sticky top-0">
                <tr>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Subject</th>
                  <th className="py-2.5 px-4">Topic Covered</th>
                  <th className="py-2.5 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                {student.attendanceHistory?.slice(0, 20).map(rec => (
                  <tr key={rec.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-4 font-mono text-slate-300">{rec.date}</td>
                    <td className="py-2.5 px-4 font-bold text-white">{rec.subjectCode}</td>
                    <td className="py-2.5 px-4 text-slate-300 truncate max-w-xs">{rec.topic}</td>
                    <td className="py-2.5 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        rec.status === 'PRESENT' ? 'bg-emerald-500/20 text-emerald-300' :
                        rec.status === 'LATE' ? 'bg-amber-500/20 text-amber-300' :
                        rec.status === 'EXCUSED' ? 'bg-cyan-500/20 text-cyan-300' :
                        'bg-rose-500/20 text-rose-300'
                      }`}>
                        {rec.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
