import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  BookOpen,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Save,
  CheckCheck,
  Search,
  Sparkles,
  Users
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function AttendanceSheet({
  subjects,
  selectedSubjectId,
  onSubjectChange,
  rosterData,
  onSubmitAttendance,
  isSubmitting
}) {
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [slot, setSlot] = useState('09:00 - 10:00 AM');
  const [topic, setTopic] = useState('');
  const [records, setRecords] = useState({});
  const [search, setSearch] = useState('');

  // Default time slots
  const timeSlots = [
    '09:00 - 10:00 AM',
    '10:15 - 11:15 AM',
    '11:30 - 12:30 PM',
    '01:30 - 02:30 PM',
    '02:45 - 03:45 PM'
  ];

  // Initialize all students as PRESENT whenever rosterData changes
  useEffect(() => {
    if (rosterData?.students) {
      const initial = {};
      rosterData.students.forEach(s => {
        initial[s.id] = { status: 'PRESENT', remarks: '' };
      });
      setRecords(initial);
    }
  }, [rosterData]);

  const students = rosterData?.students || [];

  // Bulk actions
  const markAll = (status) => {
    const updated = { ...records };
    students.forEach(s => {
      updated[s.id] = { ...updated[s.id], status };
    });
    setRecords(updated);
  };

  const setStudentStatus = (studentId, status) => {
    setRecords(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
  };

  // Calculate live counts
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;

  Object.values(records).forEach(r => {
    if (r.status === 'PRESENT') presentCount++;
    else if (r.status === 'ABSENT') absentCount++;
    else if (r.status === 'LATE') lateCount++;
  });

  const total = students.length;
  const livePercent = total > 0 ? (((presentCount + lateCount) / total) * 100).toFixed(1) : 0;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!topic.trim()) {
      alert('Please enter a lecture topic title for the session.');
      return;
    }

    const payloadRecords = students.map(s => ({
      studentId: s.id,
      status: records[s.id]?.status || 'PRESENT',
      remarks: records[s.id]?.remarks || ''
    }));

    const payload = {
      subjectId: selectedSubjectId,
      date,
      slot,
      topic: topic.trim(),
      records: payloadRecords
    };

    const success = await onSubmitAttendance(payload);
    if (success) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
      setTopic('');
    }
  };

  const filteredStudents = students.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.rollNo.toLowerCase().includes(search.toLowerCase())
  );

  const currentSubject = subjects.find(s => s.id === selectedSubjectId);

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden backdrop-blur-md p-4 sm:p-6 space-y-6">
      {/* Subject and Session Configuration Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-5 border-b border-slate-800 gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/20 text-indigo-400 font-bold text-xs uppercase border border-indigo-500/30">
                Daily Attendance Logging
              </span>
              <span className="text-xs text-slate-400">Class Roster Marking Sheet</span>
            </div>
            <h2 className="text-xl font-black text-white mt-1">
              Mark Class Session Attendance
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Subject Faculty: <strong className="text-slate-200">{currentSubject?.facultyName || 'Faculty Mentor'}</strong> • Room: {currentSubject?.room || 'LH-302'}
            </p>
          </div>

          {/* Subject Dropdown Selector */}
          <div className="w-full md:w-72">
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Select Subject
            </label>
            <select
              value={selectedSubjectId}
              onChange={(e) => onSubjectChange(e.target.value)}
              className="w-full bg-slate-950 text-white text-xs font-semibold rounded-xl px-3.5 py-2.5 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>
                  {s.code} - {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Date, Slot, Topic Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Session Date
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Time Slot
            </label>
            <div className="relative">
              <Clock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <select
                value={slot}
                onChange={(e) => setSlot(e.target.value)}
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                {timeSlots.map(ts => (
                  <option key={ts} value={ts}>{ts}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Lecture Topic / Laboratory Unit
            </label>
            <div className="relative">
              <BookOpen className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="e.g. Graph Algorithms: Dijkstra & Prim's"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                required
                className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder-slate-500"
              />
            </div>
          </div>
        </div>

        {/* Rapid Marking Controls & Live Counter Bar */}
        <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Live Counts */}
          <div className="flex items-center space-x-4 text-xs font-bold">
            <div className="flex items-center space-x-1.5 text-slate-300">
              <Users className="h-4 w-4 text-slate-400" />
              <span>Total: <strong className="text-white">{total}</strong></span>
            </div>
            <div className="flex items-center space-x-1.5 text-emerald-400">
              <CheckCircle2 className="h-4 w-4" />
              <span>Present: <strong>{presentCount}</strong></span>
            </div>
            <div className="flex items-center space-x-1.5 text-rose-400">
              <XCircle className="h-4 w-4" />
              <span>Absent: <strong>{absentCount}</strong></span>
            </div>
            <div className="flex items-center space-x-1.5 text-amber-400">
              <AlertCircle className="h-4 w-4" />
              <span>Late: <strong>{lateCount}</strong></span>
            </div>
            <div className="pl-3 border-l border-slate-800 text-indigo-400">
              Live Rate: <strong>{livePercent}%</strong>
            </div>
          </div>

          {/* Bulk Toggles */}
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => markAll('PRESENT')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition"
            >
              <CheckCheck className="h-4 w-4 text-emerald-400" />
              <span>Mark All Present</span>
            </button>

            <button
              type="button"
              onClick={() => markAll('ABSENT')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold transition"
            >
              <XCircle className="h-4 w-4 text-rose-400" />
              <span>Mark All Absent</span>
            </button>
          </div>
        </div>

        {/* Search Student In Marking Sheet */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Quick search student to toggle absence..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder-slate-500"
          />
        </div>

        {/* Student Marking Grid / Table */}
        <div className="border border-slate-800 rounded-xl overflow-hidden max-h-[420px] overflow-y-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 sticky top-0 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider z-10">
              <tr>
                <th className="py-2.5 px-4">Roll No</th>
                <th className="py-2.5 px-4">Student Name</th>
                <th className="py-2.5 px-4">Subject Standing</th>
                <th className="py-2.5 px-4">Current Risk</th>
                <th className="py-2.5 px-4 text-center">Attendance Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
              {filteredStudents.map(student => {
                const currentStatus = records[student.id]?.status || 'PRESENT';

                return (
                  <tr
                    key={student.id}
                    className={`hover:bg-slate-800/50 transition ${
                      currentStatus === 'ABSENT' ? 'bg-rose-950/20' : ''
                    }`}
                  >
                    <td className="py-2.5 px-4 font-mono font-medium text-slate-300">
                      {student.rollNo}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-white">
                      {student.name}
                    </td>
                    <td className="py-2.5 px-4 font-mono">
                      <span className="font-bold text-slate-200">{student.percentage}%</span>
                      <span className="text-[11px] text-slate-500 ml-1.5">
                        ({student.attended}/{student.totalClasses})
                      </span>
                    </td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        student.riskTier === 'CRITICAL'
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          : student.riskTier === 'WARNING'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      }`}>
                        {student.riskTier}
                      </span>
                    </td>
                    <td className="py-2.5 px-4">
                      {/* 3-State Toggle Button Group */}
                      <div className="flex items-center justify-center space-x-1.5">
                        <button
                          type="button"
                          onClick={() => setStudentStatus(student.id, 'PRESENT')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs transition ${
                            currentStatus === 'PRESENT'
                              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 ring-1 ring-emerald-400'
                              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          Present
                        </button>

                        <button
                          type="button"
                          onClick={() => setStudentStatus(student.id, 'ABSENT')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs transition ${
                            currentStatus === 'ABSENT'
                              ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30 ring-1 ring-rose-400'
                              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          Absent
                        </button>

                        <button
                          type="button"
                          onClick={() => setStudentStatus(student.id, 'LATE')}
                          className={`px-2.5 py-1 rounded-lg font-bold text-xs transition ${
                            currentStatus === 'LATE'
                              ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30 ring-1 ring-amber-400'
                              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          Late
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Submit Attendance Session */}
        <div className="flex items-center justify-end space-x-3 pt-3">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex items-center space-x-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition disabled:opacity-50 cursor-pointer"
          >
            <Save className="h-4 w-4" />
            <span>{isSubmitting ? 'Recording & Recalculating...' : 'Submit Session & Recalculate Attendance'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
