import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  MessageSquarePlus,
  MailWarning,
  TrendingUp,
  ShieldCheck,
  Sparkles,
  ArrowUpDown
} from 'lucide-react';

export default function AtRiskTable({
  students,
  subjects,
  filterTier,
  setFilterTier,
  searchQuery,
  setSearchQuery,
  filterSubject,
  setFilterSubject,
  onInspectStudent,
  onLogMentoring,
  onSendAlert
}) {
  const [sortField, setSortField] = useState('overallPercentage');
  const [sortAsc, setSortAsc] = useState(true);

  // Client-side instant filtering (< 0.1ms)
  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      // Risk tier filter
      if (filterTier === 'CRITICAL') {
        if (s.overallRiskTier !== 'CRITICAL' && s.criticalSubjectCount === 0) return false;
      } else if (filterTier === 'WARNING') {
        if (s.overallRiskTier !== 'WARNING' && (s.warningSubjectCount === 0 || s.overallRiskTier === 'CRITICAL')) return false;
      } else if (filterTier === 'SAFE') {
        if (s.overallRiskTier !== 'SAFE' || s.criticalSubjectCount > 0 || s.warningSubjectCount > 0) return false;
      }

      // Subject filter
      if (filterSubject !== 'ALL') {
        const sub = s.subjectBreakdown.find(b => b.subjectId === filterSubject);
        if (!sub) return false;
      }

      // Search query
      if (searchQuery && searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = s.name.toLowerCase().includes(q);
        const matchRoll = s.rollNo.toLowerCase().includes(q);
        const matchEmail = s.email.toLowerCase().includes(q);
        if (!matchName && !matchRoll && !matchEmail) return false;
      }

      return true;
    });
  }, [students, filterTier, filterSubject, searchQuery]);

  // Sorting
  const sortedStudents = useMemo(() => {
    return [...filteredStudents].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      if (typeof aVal === 'string') {
        return sortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortAsc ? aVal - bVal : bVal - aVal;
    });
  }, [filteredStudents, sortField, sortAsc]);

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(field === 'overallPercentage' ? true : false);
    }
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden backdrop-blur-md">
      {/* Table Controls / Filters Header */}
      <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Risk Tier Tabs */}
        <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Roster' },
            { id: 'CRITICAL', label: 'Critical (<65%)', color: 'rose' },
            { id: 'WARNING', label: 'Warning (65-74%)', color: 'amber' },
            { id: 'SAFE', label: 'Safe (≥75%)', color: 'emerald' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterTier(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                filterTier === tab.id
                  ? tab.color === 'rose'
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                    : tab.color === 'amber'
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : tab.color === 'emerald'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search & Subject Filter */}
        <div className="flex items-center space-x-3 w-full lg:w-auto">
          {/* Subject Filter */}
          <div className="relative min-w-[140px] sm:min-w-[170px]">
            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl px-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All 5 Subjects</option>
              {subjects.map(s => (
                <option key={s.id} value={s.id}>
                  {s.code} - {s.shortName}
                </option>
              ))}
            </select>
          </div>

          {/* Search Box */}
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search name, roll no..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 text-slate-200 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder-slate-500"
            />
          </div>
        </div>
      </div>

      {/* Roster Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-950/70 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <th className="py-3 px-4 sm:px-6">Student Information</th>
              <th
                className="py-3 px-4 cursor-pointer hover:text-slate-200 transition"
                onClick={() => toggleSort('overallPercentage')}
              >
                <div className="flex items-center space-x-1">
                  <span>Overall %</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th className="py-3 px-4">Risk Classification</th>
              <th className="py-3 px-4">Subject Deficits & Shortage</th>
              <th className="py-3 px-4">Recovery Forecast (75% Rule)</th>
              <th className="py-3 px-4 sm:px-6 text-right">Mentor Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-xs">
            {sortedStudents.length === 0 ? (
              <tr>
                <td colSpan="6" className="py-12 text-center text-slate-400">
                  No students match the current filter criteria.
                </td>
              </tr>
            ) : (
              sortedStudents.map(student => {
                const isCritical = student.overallRiskTier === 'CRITICAL' || student.criticalSubjectCount > 0;
                const isWarning = !isCritical && (student.overallRiskTier === 'WARNING' || student.warningSubjectCount > 0);
                const isRahul = student.id === 'STU001';

                // Subject specific data if subject filtered
                const activeSubStat = filterSubject !== 'ALL'
                  ? student.subjectBreakdown.find(b => b.subjectId === filterSubject)
                  : null;

                const displayPercentage = activeSubStat ? activeSubStat.percentage : student.overallPercentage;
                const displayRiskTier = activeSubStat ? activeSubStat.riskTier : student.overallRiskTier;
                const displayClassesNeeded = activeSubStat ? activeSubStat.classesNeeded : student.overallClassesNeeded;
                const displayBunkAllowance = activeSubStat ? activeSubStat.bunkAllowance : student.overallBunkAllowance;

                return (
                  <tr
                    key={student.id}
                    className={`hover:bg-slate-800/40 transition group ${
                      isRahul ? 'bg-indigo-950/20' : ''
                    }`}
                  >
                    {/* Student Info */}
                    <td className="py-3.5 px-4 sm:px-6">
                      <div className="flex items-center space-x-3">
                        <div className={`h-9 w-9 rounded-xl flex items-center justify-center font-bold text-xs ring-1 ${
                          isCritical
                            ? 'bg-rose-500/20 text-rose-300 ring-rose-500/30'
                            : isWarning
                            ? 'bg-amber-500/20 text-amber-300 ring-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 ring-emerald-500/30'
                        }`}>
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-white group-hover:text-indigo-400 transition">
                              {student.name}
                            </span>
                            {isRahul && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                Demo Focus
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 flex items-center space-x-2 mt-0.5">
                            <span className="font-mono text-slate-300 font-medium">{student.rollNo}</span>
                            <span>•</span>
                            <span>Sem {student.semester} - {student.section}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Overall Attendance % with Gauge */}
                    <td className="py-3.5 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between font-mono font-bold text-sm">
                          <span className={
                            displayRiskTier === 'CRITICAL' ? 'text-rose-400' :
                            displayRiskTier === 'WARNING' ? 'text-amber-400' : 'text-emerald-400'
                          }>
                            {displayPercentage}%
                          </span>
                          <span className="text-[10px] text-slate-500 font-normal">
                            {activeSubStat
                              ? `${activeSubStat.attended}/${activeSubStat.totalClasses}`
                              : `${student.totalAttended}/${student.totalClasses}`}
                          </span>
                        </div>
                        {/* Progress Bar */}
                        <div className="h-1.5 w-28 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              displayRiskTier === 'CRITICAL' ? 'bg-rose-500' :
                              displayRiskTier === 'WARNING' ? 'bg-amber-500' : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(100, displayPercentage)}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Risk Badge */}
                    <td className="py-3.5 px-4">
                      {displayRiskTier === 'CRITICAL' ? (
                        <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse">
                          <AlertOctagon className="h-3.5 w-3.5 text-rose-400" />
                          <span>CRITICAL (&lt;65%)</span>
                        </span>
                      ) : displayRiskTier === 'WARNING' ? (
                        <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                          <span>WARNING (65-74%)</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                          <span>SAFE (≥75%)</span>
                        </span>
                      )}
                    </td>

                    {/* Shortage Subjects Chips */}
                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap gap-1.5 max-w-xs">
                        {student.subjectBreakdown
                          .filter(sub => sub.riskTier === 'CRITICAL' || sub.riskTier === 'WARNING')
                          .map(sub => (
                            <span
                              key={sub.subjectId}
                              className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                                sub.riskTier === 'CRITICAL'
                                  ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                                  : 'bg-amber-950/60 text-amber-300 border-amber-800'
                              }`}
                              title={`${sub.name}: ${sub.percentage}%, Needs ${sub.classesNeeded} classes`}
                            >
                              {sub.shortName}: {sub.percentage}%
                              {sub.classesNeeded > 0 && ` (${sub.classesNeeded} needed)`}
                            </span>
                          ))}
                        {student.subjectBreakdown.filter(sub => sub.riskTier !== 'SAFE').length === 0 && (
                          <span className="text-[11px] text-slate-500 italic flex items-center space-x-1">
                            <ShieldCheck className="h-3 w-3 text-emerald-400" />
                            <span>All subjects ≥ 75%</span>
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Recovery Forecast: Key Formula Result */}
                    <td className="py-3.5 px-4">
                      {displayClassesNeeded > 0 ? (
                        <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-slate-950 border border-rose-500/40 text-rose-300 font-medium">
                          <TrendingUp className="h-3.5 w-3.5 text-rose-400 shrink-0" />
                          <div>
                            <span className="font-extrabold text-white text-xs">{displayClassesNeeded}</span>
                            <span className="text-[11px] ml-1 text-slate-300">classes required</span>
                          </div>
                        </div>
                      ) : (
                        <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-slate-950 border border-emerald-500/30 text-emerald-400">
                          <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
                          <span className="text-[11px] font-medium text-slate-300">
                            Can skip <strong className="text-emerald-400">{displayBunkAllowance}</strong> classes safely
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Actions Column */}
                    <td className="py-3.5 px-4 sm:px-6 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        {/* Inspect Profile */}
                        <button
                          onClick={() => onInspectStudent(student)}
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-600/90 hover:bg-indigo-600 text-white font-semibold text-xs transition shadow-sm"
                          title="View Student Subject Breakdown & Logs"
                        >
                          Inspect
                        </button>

                        {/* Log Mentoring Intervention */}
                        <button
                          onClick={() => onLogMentoring(student)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-purple-300 hover:text-white border border-slate-700 transition"
                          title="Log Mentoring Intervention Counseling"
                        >
                          <MessageSquarePlus className="h-4 w-4" />
                        </button>

                        {/* Send Simulated Alert */}
                        <button
                          onClick={() => onSendAlert(student)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 hover:text-white border border-slate-700 transition"
                          title="Send Warning Email to Student & Parent"
                        >
                          <MailWarning className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
