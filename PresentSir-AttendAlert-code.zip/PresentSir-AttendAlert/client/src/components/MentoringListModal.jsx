import React, { useState } from 'react';
import { X, MessageSquare, CheckCircle2, Clock, UserCheck, AlertTriangle } from 'lucide-react';

export default function MentoringListModal({
  interventions,
  onClose,
  onUpdateStatus
}) {
  const [filterStatus, setFilterStatus] = useState('ALL');

  const filtered = filterStatus === 'ALL'
    ? interventions
    : interventions.filter(i => i.status === filterStatus);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400">
              <MessageSquare className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-purple-400">
                Academic Counseling Registry
              </div>
              <h3 className="text-lg font-black text-white">
                Mentoring Interventions & Recovery Contracts ({interventions?.length || 0})
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="px-6 py-3 border-b border-slate-800 flex items-center space-x-2">
          {['ALL', 'Open', 'In Progress', 'Resolved'].map(st => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                filterStatus === st
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Interventions List */}
        <div className="p-6 max-h-[500px] overflow-y-auto space-y-4">
          {filtered?.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No mentoring intervention logs found.
            </div>
          ) : (
            filtered.map(item => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-extrabold text-white text-sm">{item.studentName}</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {item.rollNo}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300">
                      {item.interventionType}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <select
                      value={item.status}
                      onChange={(e) => onUpdateStatus(item.id, e.target.value)}
                      className="bg-slate-900 text-purple-300 text-xs font-bold rounded-lg px-2.5 py-1 border border-slate-700"
                    >
                      <option value="Open">Open</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Resolved">Resolved</option>
                    </select>
                  </div>
                </div>

                <div className="text-xs text-slate-300">
                  <strong>Notes:</strong> {item.counselingNotes}
                </div>

                {item.actionPlan && (
                  <div className="text-xs text-indigo-300 bg-indigo-950/20 p-2.5 rounded-xl border border-indigo-900/30">
                    <strong>Action Plan:</strong> {item.actionPlan}
                  </div>
                )}

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                  <span>Mentor: <strong>{item.mentorName}</strong> ({new Date(item.date).toLocaleDateString()})</span>
                  <span>Follow-up: <strong className="text-amber-400">{item.nextFollowUpDate || 'None'}</strong></span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
