import React from 'react';
import {
  GraduationCap,
  ShieldAlert,
  UserCheck,
  FileSpreadsheet,
  Mail,
  FileHeart,
  RotateCcw,
  User,
  Download
} from 'lucide-react';

export default function Header({
  activeRole,
  setActiveRole,
  overview,
  onResetDemo,
  onOpenAlertHistory,
  onOpenMedicalWorkflow,
  onOpenCsvModal,
  selectedStudent,
  students,
  onSelectStudent
}) {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Name */}
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-amber-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-black tracking-tight text-white">PresentSir</span>
                <span className="px-2 py-0.5 text-xs font-bold uppercase rounded-md bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  AttendAlert
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Predictive Attendance & Early-Warning Recovery Engine (75% Statutory Rule)
              </p>
            </div>
          </div>

          {/* Role Switcher & Action Bar */}
          <div className="flex items-center space-x-3">
            {/* Role Switcher Pill */}
            <div className="bg-slate-800/90 p-1 rounded-xl border border-slate-700/80 flex items-center shadow-inner">
              <button
                onClick={() => setActiveRole('mentor')}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeRole === 'mentor'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <UserCheck className="h-4 w-4" />
                <span>Mentor / Faculty</span>
              </button>

              <button
                onClick={() => setActiveRole('student')}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeRole === 'student'
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <User className="h-4 w-4" />
                <span>Student Portal</span>
              </button>
            </div>

            {/* Quick Actions (Mentor View) */}
            {activeRole === 'mentor' && (
              <div className="hidden md:flex items-center space-x-2">
                {/* Medical Clearance Approvals */}
                <button
                  onClick={onOpenMedicalWorkflow}
                  className="relative p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700 transition"
                  title="Medical Leave Condonation Approvals"
                >
                  <FileHeart className="h-4 w-4 text-emerald-400" />
                  {overview?.pendingMedicalCount > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-[10px] font-bold text-white ring-2 ring-slate-900">
                      {overview.pendingMedicalCount}
                    </span>
                  )}
                </button>

                {/* Simulated Email Outbox */}
                <button
                  onClick={onOpenAlertHistory}
                  className="relative p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700 transition"
                  title="Simulated Email Dispatch Logs"
                >
                  <Mail className="h-4 w-4 text-rose-400" />
                </button>

                {/* CSV Importer */}
                <button
                  onClick={onOpenCsvModal}
                  className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700 transition"
                  title="Import Biometric / CSV Rosters"
                >
                  <FileSpreadsheet className="h-4 w-4 text-cyan-400" />
                </button>

                {/* Download CSV Export */}
                <a
                  href="/api/roster/export-csv"
                  download="PresentSir_Attendance_Roster_Report.csv"
                  className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700 transition"
                  title="Download Attendance Matrix CSV"
                >
                  <FileSpreadsheet className="h-4 w-4 text-amber-400" />
                </a>

                {/* Download Full Project ZIP */}
                <a
                  href="/download-zip"
                  download="PresentSir-AttendAlert.zip"
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs font-bold transition shadow-md shadow-indigo-600/30 ring-1 ring-white/10"
                  title="Download Complete Source Code ZIP"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download ZIP</span>
                </a>

                {/* Demo Reset Button */}
                <button
                  onClick={onResetDemo}
                  className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-400 border border-slate-700 text-xs font-medium transition"
                  title="Reset Demo Scenario to Initial State"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span className="hidden lg:inline">Reset Demo</span>
                </button>
              </div>
            )}

            {/* Student Switcher dropdown when in Student View */}
            {activeRole === 'student' && students && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-400 hidden sm:inline">Viewing as:</span>
                <select
                  value={selectedStudent?.id || ''}
                  onChange={(e) => {
                    const stu = students.find(s => s.id === e.target.value);
                    if (stu) onSelectStudent(stu);
                  }}
                  className="bg-slate-800 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 border border-slate-700 focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.rollNo}) - {s.overallPercentage}%
                    </option>
                  ))}
                </select>

                <a
                  href="/download-zip"
                  download="PresentSir-AttendAlert.zip"
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white text-xs font-bold transition shadow-md shadow-amber-600/30"
                  title="Download Complete Source Code ZIP"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download ZIP</span>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
