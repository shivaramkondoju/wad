import React, { useState } from 'react';
import { X, FileSpreadsheet, Upload, CheckCircle2, Download, AlertCircle } from 'lucide-react';

export default function CsvImportModal({ onClose, onImportSuccess }) {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState(null);

  const sampleCsvContent = `RollNo,Name,Email,Department,Semester,Section
21CS031,Rajat Kapoor,rajat.k@college.edu,Computer Science & Engineering,5,A
21CS032,Nidhi Agarwal,nidhi.a@college.edu,Computer Science & Engineering,5,A
21CS033,Aditi Saxena,aditi.s@college.edu,Computer Science & Engineering,5,A`;

  const handleDownloadSample = () => {
    const blob = new Blob([sampleCsvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_attendance_roster.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      alert('Please select a CSV file to upload.');
      return;
    }

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/roster/import-csv', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      setResult(data);
      if (onImportSuccess) onImportSuccess();
    } catch (err) {
      alert('CSV upload error: ' + err.message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400">
              <FileSpreadsheet className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Data Integration & Biometric Upload
              </div>
              <h3 className="text-lg font-black text-white">
                Import CSV Roster or Attendance Dumps
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleUpload} className="p-6 space-y-4">
          <p className="text-xs text-slate-400">
            Upload CSV files containing student rosters or biometric logs. System will automatically map columns, detect duplicates, and compute early-warning thresholds.
          </p>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-white">Download Sample CSV Template</div>
              <div className="text-[11px] text-slate-400">Standard columns: RollNo, Name, Email, Dept, Sem, Sec</div>
            </div>
            <button
              type="button"
              onClick={handleDownloadSample}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-bold transition border border-slate-700"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download Template</span>
            </button>
          </div>

          <div className="border-2 border-dashed border-slate-700 rounded-2xl p-6 text-center space-y-2 bg-slate-950/50">
            <Upload className="h-8 w-8 text-slate-500 mx-auto" />
            <input
              type="file"
              accept=".csv"
              onChange={(e) => setFile(e.target.files[0])}
              className="text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500 cursor-pointer"
            />
            {file && (
              <div className="text-xs text-cyan-400 font-mono pt-2">
                Selected: {file.name} ({(file.size / 1024).toFixed(1)} KB)
              </div>
            )}
          </div>

          {result && (
            <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-xs text-emerald-300 flex items-center space-x-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
              <span>{result.message}</span>
            </div>
          )}

          <div className="flex justify-end space-x-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={isUploading || !file}
              className="flex items-center space-x-2 px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/30 transition disabled:opacity-50"
            >
              <Upload className="h-4 w-4" />
              <span>{isUploading ? 'Importing CSV...' : 'Process & Ingest CSV'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
