import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header.jsx';
import OverviewCards from './components/OverviewCards.jsx';
import CriticalBanner from './components/CriticalBanner.jsx';
import AtRiskTable from './components/AtRiskTable.jsx';
import AttendanceSheet from './components/AttendanceSheet.jsx';
import StudentDetailModal from './components/StudentDetailModal.jsx';
import MentoringModal from './components/MentoringModal.jsx';
import AlertModal from './components/AlertModal.jsx';
import MedicalWorkflowModal from './components/MedicalWorkflowModal.jsx';
import CorrelationChart from './components/CorrelationChart.jsx';
import StudentPortal from './components/StudentPortal.jsx';
import CsvImportModal from './components/CsvImportModal.jsx';
import AlertHistoryDrawer from './components/AlertHistoryDrawer.jsx';
import MentoringListModal from './components/MentoringListModal.jsx';

import {
  fetchOverview,
  fetchStudents,
  fetchStudentById,
  fetchSubjects,
  fetchSubjectRoster,
  markAttendanceSession,
  logMentoringIntervention,
  fetchMentoringLogs,
  updateMentoringLog,
  sendSimulatedAlert,
  fetchAlertHistory,
  fetchMedicalRequests,
  reviewMedicalRequest,
  submitMedicalRequest,
  fetchCorrelationData,
  resetDatabase
} from './api.js';

import {
  LayoutDashboard,
  CalendarCheck,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  Sparkles
} from 'lucide-react';

export default function App() {
  // Roles and Tabs
  const [activeRole, setActiveRole] = useState('mentor'); // 'mentor' | 'student'
  const [mentorTab, setMentorTab] = useState('dashboard'); // 'dashboard' | 'attendance' | 'analytics'

  // Data States
  const [overview, setOverview] = useState(null);
  const [students, setStudents] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState('CS501');
  const [rosterData, setRosterData] = useState(null);
  const [correlationData, setCorrelationData] = useState(null);
  const [medicalRequests, setMedicalRequests] = useState([]);
  const [alertLogs, setAlertLogs] = useState([]);
  const [mentoringLogs, setMentoringLogs] = useState([]);

  // Filters
  const [filterTier, setFilterTier] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSubject, setFilterSubject] = useState('ALL');

  // Modals & Drawers
  const [inspectedStudent, setInspectedStudent] = useState(null);
  const [mentoringModalStudent, setMentoringModalStudent] = useState(null);
  const [alertModalStudent, setAlertModalStudent] = useState(null);
  const [isMedicalWorkflowOpen, setIsMedicalWorkflowOpen] = useState(false);
  const [isAlertHistoryOpen, setIsAlertHistoryOpen] = useState(false);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [isMentoringListOpen, setIsMentoringListOpen] = useState(false);

  // Student Portal Active Student (Default: Rahul Verma - STU001)
  const [studentPortalUser, setStudentPortalUser] = useState(null);

  // Loading States & Toast
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmittingAttendance, setIsSubmittingAttendance] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  // Master Data Refresh - fast single batch fetch
  const loadAllData = useCallback(async () => {
    try {
      const [
        overviewRes,
        studentsRes,
        subjectsRes,
        correlationRes,
        medicalRes,
        alertRes,
        mentoringRes
      ] = await Promise.all([
        fetchOverview(),
        fetchStudents(), // Loads all students once; filtering is instant client-side
        fetchSubjects(),
        fetchCorrelationData(),
        fetchMedicalRequests(),
        fetchAlertHistory(),
        fetchMentoringLogs()
      ]);

      setOverview(overviewRes);
      setStudents(studentsRes);
      setSubjects(subjectsRes);
      setCorrelationData(correlationRes);
      setMedicalRequests(medicalRes);
      setAlertLogs(alertRes);
      setMentoringLogs(mentoringRes);

      // Set default student for student portal (Rahul Verma STU001)
      setStudentPortalUser(prev => {
        if (!prev) {
          const rahul = studentsRes.find(s => s.id === 'STU001') || studentsRes[0];
          return rahul || null;
        }
        const updated = studentsRes.find(s => s.id === prev.id);
        return updated || prev;
      });

      // If inspected student is open, refresh their data too
      setInspectedStudent(prev => {
        if (!prev) return null;
        const fresh = studentsRes.find(s => s.id === prev.id);
        return fresh || prev;
      });
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Load subject roster for attendance marking
  const loadSubjectRoster = useCallback(async (subId) => {
    try {
      const data = await fetchSubjectRoster(subId);
      setRosterData(data);
    } catch (err) {
      console.error('Failed to fetch roster:', err);
    }
  }, []);

  useEffect(() => {
    if (selectedSubjectId) {
      loadSubjectRoster(selectedSubjectId);
    }
  }, [selectedSubjectId, loadSubjectRoster]);

  // Handler: Inspect Student in Modal (instant modal display)
  const handleInspectStudent = async (student) => {
    setInspectedStudent(student);
    try {
      const full = await fetchStudentById(student.id);
      setInspectedStudent(full);
    } catch (err) {
      console.error('Failed to load extra student history:', err);
    }
  };

  // Handler: Submit Attendance Session
  const handleSubmitAttendance = async (payload) => {
    setIsSubmittingAttendance(true);
    try {
      await markAttendanceSession(payload);
      showToast('Attendance recorded successfully! Batch standing and recovery calculations updated.', 'success');
      await loadAllData();
      await loadSubjectRoster(selectedSubjectId);
      return true;
    } catch (err) {
      showToast('Error recording attendance: ' + err.message, 'error');
      return false;
    } finally {
      setIsSubmittingAttendance(false);
    }
  };

  // Handler: Log Mentoring Intervention
  const handleLogMentoring = async (payload) => {
    try {
      await logMentoringIntervention(payload);
      showToast(`Mentoring intervention logged for ${payload.studentName}!`, 'success');
      await loadAllData();
    } catch (err) {
      showToast('Error logging intervention: ' + err.message, 'error');
    }
  };

  // Handler: Update Mentoring Status
  const handleUpdateMentoringStatus = async (id, status) => {
    try {
      await updateMentoringLog(id, { status });
      showToast('Mentoring case status updated to ' + status, 'success');
      await loadAllData();
    } catch (err) {
      showToast('Error updating status: ' + err.message, 'error');
    }
  };

  // Handler: Send Warning Alert
  const handleSendAlert = async (payload) => {
    try {
      const res = await sendSimulatedAlert(payload);
      showToast(res.message, 'success');
      await loadAllData();
    } catch (err) {
      showToast('Error sending warning notice: ' + err.message, 'error');
    }
  };

  // Handler: Review Medical Request
  const handleReviewMedical = async (id, payload) => {
    try {
      const res = await reviewMedicalRequest(id, payload);
      showToast(res.message, 'success');
      await loadAllData();
    } catch (err) {
      showToast('Error reviewing medical request: ' + err.message, 'error');
    }
  };

  // Handler: Submit Medical Request from Student Portal
  const handleSubmitMedicalFromStudent = async (formData) => {
    try {
      await submitMedicalRequest(formData);
      showToast('Medical certificate submitted! Awaiting mentor approval.', 'success');
      await loadAllData();
    } catch (err) {
      showToast('Error submitting medical application: ' + err.message, 'error');
    }
  };

  // Handler: Reset Demo Scenario
  const handleResetDemo = async () => {
    if (window.confirm('Reset database to clean hackathon seed scenario (30 students, 5 critical cases, Rahul Verma demo)?')) {
      try {
        await resetDatabase();
        showToast('Database reset to original hackathon seed scenario!', 'success');
        await loadAllData();
        await loadSubjectRoster(selectedSubjectId);
      } catch (err) {
        showToast('Error resetting demo: ' + err.message, 'error');
      }
    }
  };

  // Select student for student self-service portal
  const handleSelectStudentForPortal = async (stu) => {
    try {
      const full = await fetchStudentById(stu.id);
      setStudentPortalUser(full);
    } catch (err) {
      showToast('Failed to switch student: ' + err.message, 'error');
    }
  };

  const rahulVerma = students.find(s => s.id === 'STU001');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-20 right-6 z-50 flex items-center space-x-2.5 px-4 py-3 rounded-2xl shadow-2xl backdrop-blur-md border animate-bounce text-xs font-bold bg-slate-900/95 border-indigo-500 text-white">
          {toast.type === 'error' ? (
            <AlertCircle className="h-4 w-4 text-rose-400" />
          ) : (
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Global Navigation Header */}
      <Header
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        overview={overview}
        onResetDemo={handleResetDemo}
        onOpenAlertHistory={() => setIsAlertHistoryOpen(true)}
        onOpenMedicalWorkflow={() => setIsMedicalWorkflowOpen(true)}
        onOpenCsvModal={() => setIsCsvModalOpen(true)}
        selectedStudent={studentPortalUser}
        students={students}
        onSelectStudent={handleSelectStudentForPortal}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* MENTOR / FACULTY VIEW */}
        {activeRole === 'mentor' && (
          <div className="space-y-6">
            {/* View Sub-Tabs (Dashboard | Attendance Marking | Correlation Analytics) */}
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
              {[
                { id: 'dashboard', label: 'Early-Warning Roster Dashboard', icon: LayoutDashboard },
                { id: 'attendance', label: 'Faculty Attendance Sheet', icon: CalendarCheck },
                { id: 'analytics', label: 'Marks Correlation Analytics', icon: BarChart3 }
              ].map(tab => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setMentorTab(tab.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
                      mentorTab === tab.id
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* TAB: DASHBOARD */}
            {mentorTab === 'dashboard' && (
              <div className="space-y-6">
                {/* Critical Shortage Alert Banner (Key Hackathon Prompt Requirement) */}
                <CriticalBanner
                  criticalCount={overview?.criticalCount || 0}
                  onFilterCritical={() => setFilterTier('CRITICAL')}
                  onQuickInspectStudent={handleInspectStudent}
                  rahulVerma={rahulVerma}
                />

                {/* Summary Metrics Cards */}
                <OverviewCards
                  overview={overview}
                  activeFilter={filterTier}
                  onSelectFilter={(tier) => setFilterTier(tier)}
                  onOpenMedical={() => setIsMedicalWorkflowOpen(true)}
                  onOpenMentoringList={() => setIsMentoringListOpen(true)}
                />

                {/* Filterable At-Risk Student Table */}
                <AtRiskTable
                  students={students}
                  subjects={subjects}
                  filterTier={filterTier}
                  setFilterTier={setFilterTier}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  filterSubject={filterSubject}
                  setFilterSubject={setFilterSubject}
                  onInspectStudent={handleInspectStudent}
                  onLogMentoring={(s) => setMentoringModalStudent(s)}
                  onSendAlert={(s) => setAlertModalStudent(s)}
                />
              </div>
            )}

            {/* TAB: FACULTY ATTENDANCE SHEET */}
            {mentorTab === 'attendance' && (
              <AttendanceSheet
                subjects={subjects}
                selectedSubjectId={selectedSubjectId}
                onSubjectChange={(id) => setSelectedSubjectId(id)}
                rosterData={rosterData}
                onSubmitAttendance={handleSubmitAttendance}
                isSubmitting={isSubmittingAttendance}
              />
            )}

            {/* TAB: MARKS CORRELATION ANALYTICS */}
            {mentorTab === 'analytics' && (
              <CorrelationChart
                correlationData={correlationData}
                subjects={subjects}
              />
            )}
          </div>
        )}

        {/* STUDENT SELF-SERVICE VIEW */}
        {activeRole === 'student' && (
          <StudentPortal
            student={studentPortalUser}
            onSubmitMedical={handleSubmitMedicalFromStudent}
            onRefreshStudent={loadAllData}
          />
        )}
      </main>

      {/* MODALS & DRAWERS */}
      {inspectedStudent && (
        <StudentDetailModal
          student={inspectedStudent}
          onClose={() => setInspectedStudent(null)}
          onLogMentoring={(s) => setMentoringModalStudent(s)}
          onSendAlert={(s) => setAlertModalStudent(s)}
        />
      )}

      {mentoringModalStudent && (
        <MentoringModal
          student={mentoringModalStudent}
          onClose={() => setMentoringModalStudent(null)}
          onSubmit={handleLogMentoring}
        />
      )}

      {alertModalStudent && (
        <AlertModal
          student={alertModalStudent}
          onClose={() => setAlertModalStudent(null)}
          onSendAlert={handleSendAlert}
        />
      )}

      {isMedicalWorkflowOpen && (
        <MedicalWorkflowModal
          medicalRequests={medicalRequests}
          onClose={() => setIsMedicalWorkflowOpen(false)}
          onReviewRequest={handleReviewMedical}
        />
      )}

      {isAlertHistoryOpen && (
        <AlertHistoryDrawer
          alerts={alertLogs}
          onClose={() => setIsAlertHistoryOpen(false)}
        />
      )}

      {isCsvModalOpen && (
        <CsvImportModal
          onClose={() => setIsCsvModalOpen(false)}
          onImportSuccess={loadAllData}
        />
      )}

      {isMentoringListOpen && (
        <MentoringListModal
          interventions={mentoringLogs}
          onClose={() => setIsMentoringListOpen(false)}
          onUpdateStatus={handleUpdateMentoringStatus}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <strong>PresentSir / AttendAlert</strong> • Hackathon Solution for Predictive Attendance & Early-Warning Recovery
          </div>
          <div className="font-mono text-slate-600">
            Formula: ceil((0.75 * Total - Attended) / 0.25) • 75% Statutory Cutoff
          </div>
        </div>
      </footer>
    </div>
  );
}
