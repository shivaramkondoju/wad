/**
 * PresentSir / AttendAlert - API Client
 */

const API_BASE = '/api';

export async function fetchOverview() {
  const res = await fetch(`${API_BASE}/stats/overview`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch overview');
  return data.data;
}

export async function fetchStudents({ search = '', riskTier = 'ALL', subjectId = 'ALL' } = {}) {
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (riskTier && riskTier !== 'ALL') params.set('riskTier', riskTier);
  if (subjectId && subjectId !== 'ALL') params.set('subjectId', subjectId);

  const res = await fetch(`${API_BASE}/students?${params.toString()}`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch students');
  return data.data;
}

export async function fetchStudentById(id) {
  const res = await fetch(`${API_BASE}/students/${id}`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch student details');
  return data.data;
}

export async function fetchSubjects() {
  const res = await fetch(`${API_BASE}/subjects`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch subjects');
  return data.data;
}

export async function fetchSubjectRoster(subjectId) {
  const res = await fetch(`${API_BASE}/subjects/${subjectId}/roster`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch subject roster');
  return data.data;
}

export async function markAttendanceSession(payload) {
  const res = await fetch(`${API_BASE}/attendance/mark`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to submit attendance');
  return data.data;
}

export async function fetchAttendanceSessions() {
  const res = await fetch(`${API_BASE}/attendance/sessions`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch sessions');
  return data.data;
}

export async function logMentoringIntervention(payload) {
  const res = await fetch(`${API_BASE}/mentoring/log`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to log mentoring note');
  return data.data;
}

export async function fetchMentoringLogs(studentId = null) {
  const url = studentId ? `${API_BASE}/mentoring/logs?studentId=${studentId}` : `${API_BASE}/mentoring/logs`;
  const res = await fetch(url);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch mentoring logs');
  return data.data;
}

export async function updateMentoringLog(id, payload) {
  const res = await fetch(`${API_BASE}/mentoring/logs/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to update mentoring log');
  return data.data;
}

export async function sendSimulatedAlert(payload) {
  const res = await fetch(`${API_BASE}/alerts/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to dispatch alert');
  return data;
}

export async function fetchAlertHistory() {
  const res = await fetch(`${API_BASE}/alerts/history`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch alert history');
  return data.data;
}

export async function fetchMedicalRequests() {
  const res = await fetch(`${API_BASE}/medical/requests`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch medical requests');
  return data.data;
}

export async function submitMedicalRequest(formData) {
  const res = await fetch(`${API_BASE}/medical/submit`, {
    method: 'POST',
    body: formData
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to submit medical request');
  return data.data;
}

export async function reviewMedicalRequest(id, payload) {
  const res = await fetch(`${API_BASE}/medical/${id}/review`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to review medical request');
  return data;
}

export async function fetchCorrelationData() {
  const res = await fetch(`${API_BASE}/analytics/correlation`);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch correlation data');
  return data.data;
}

export async function uploadRosterCsv(formData) {
  const res = await fetch(`${API_BASE}/roster/import-csv`, {
    method: 'POST',
    body: formData
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to import CSV');
  return data;
}

export async function resetDatabase() {
  const res = await fetch(`${API_BASE}/reset-seed`, {
    method: 'POST'
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.error || 'Failed to reset database');
  return data;
}
