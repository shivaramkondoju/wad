# PresentSir: AttendAlert 🎓⚡
### Mentor-Facing Attendance Tracking & Predictive Early-Warning System

> Built for the **PresentSir: AttendAlert Hackathon**. Continuously computes student attendance percentages, forecasts statutory examination detention risks, and triggers automated proactive interventions before exam hall tickets are withheld.

---

## 🌟 Hackathon Solution Highlights

- **Mandatory 75% Statutory Threshold Tracking**: Real-time percentage & deficit calculation across all subjects and overall academic progress.
- **Closed-Form Recovery Engine**: Exact mathematical projection for consecutive classes needed without absence:
  $$\text{ClassesNeeded} = \left\lceil \frac{0.75 \times \text{Total} - \text{Attended}}{0.25} \right\rceil$$
- **Safety Margin / Bunk Allowance Calculator**: For students with $\ge 75\%$, computes how many classes they can afford to miss safely without dropping below eligibility.
- **Early-Warning Risk Classifier**:
  - 🔴 **Critical Shortage (< 65%)**: Immediate detention risk; automated parent/student alerts triggered.
  - 🟡 **Warning Tier (65% - 74.99%)**: Borderline shortage; proactive mentoring advised.
  - 🟢 **Safe Standing (≥ 75%)**: Full examination hall ticket eligibility.
- **Rapid Attendance Marking Sheet**: Faculty daily logging with **1-Click "Mark All Present"** bulk toggle and real-time percentage recalculation.
- **Mentor Notification Hub & Action Logging**: Dedicated intervention logging modal to record counseling discussions, action plans, and follow-up dates.
- **Student Self-Service Portal**: Private student view with personalized dashboards, interactive what-if recovery simulator, and medical leave submission.
- **Stretch Feature 1 - Automated Parent & Student Warning Notices**: Simulated multi-channel email alerts with official detention warning letter rendering and audit log.
- **Stretch Feature 2 - Medical Leave Exemption Workflow**: Student application upload with mentor verification; approval automatically converts absences to **EXCUSED** and recalculates condonation standing.
- **Stretch Feature 3 - Marks Correlation Analytics**: Recharts scatter plot computing Pearson correlation coefficient ($r = +0.748$) between attendance and midterm exam performance.
- **Stretch Feature 4 - CSV Roster Importer & Report Exporter**: Import biometric log dumps or student rosters from CSV, plus download the complete attendance matrix as CSV.

---

## 🚀 Live Demo Scenario (Walkthrough)

1. **Dashboard Banner**:
   - The mentor logs in and immediately sees the statutory alert banner: **"8 Students in Critical Shortage (<65%) - Immediate Academic Detention Intervention Required"**.
2. **Inspect Rahul Verma (`STU001`)**:
   - Rahul Verma is currently at **60.0% overall** and **62.5% in CS501 Data Structures** (10 attended out of 16 held).
   - The recovery engine computes:
     $$\text{ClassesNeeded} = \left\lceil \frac{0.75 \times 16 - 10}{0.25} \right\rceil = \left\lceil \frac{12 - 10}{0.25} \right\rceil = \left\lceil \frac{2}{0.25} \right\rceil = 8 \text{ consecutive classes}$$
   - When Rahul attends 8 consecutive classes: $(10 + 8) / (16 + 8) = 18 / 24 = \mathbf{75.0\%}$!
3. **Log Mentoring Intervention**:
   - Click **"Inspect"** -> **"Log Mentoring Intervention"**.
   - Record root cause counseling notes, action plan, and follow-up review date.
4. **Dispatch Simulated Warning Email**:
   - Click **"Dispatch Warning Email"** to preview and simulate sending an official letter to Rahul and his parents (`suresh.verma@parentmail.com`).
5. **Faculty Attendance Marking**:
   - Switch to the **Faculty Attendance Sheet** tab.
   - Select subject, date, and topic.
   - Click **"Mark All Present"** to toggle 30 students in one click, uncheck absent students, and submit to recalculate live batch standing!
6. **Student Self-Service View**:
   - Switch role toggle to **"Student Portal"**.
   - Experience Rahul's view: interactive slider to simulate future attendance, view subject deficit breakdowns, and submit medical exemptions.
7. **Medical Exemption Condonation**:
   - Open **Medical Clearances** from the top bar.
   - Review Sneha Deshmukh's pending hospitalization certificate (`MED_001`).
   - Click **"Approve & Condonate"**; the system recalculates her records to `EXCUSED` and boosts her attendance percentage instantly!

---

## 🛠️ Technology Stack

- **Frontend**: React 19, Vite, Tailwind CSS v4, Lucide React icons, Recharts, Canvas-Confetti.
- **Backend**: Node.js v26, Express 5, Multer (file uploads & CSV imports), CORS.
- **Database**: File-backed atomic JSON store with auto-seeding (`data/database.json`).
- **Mathematical Engine**: Pure closed-form linear threshold algorithms with Pearson correlation analytics.

---

## 🏃 Quick Start Guide

### Prerequisites
- Node.js (v18+ recommended, compatible with Node v26)
- npm

### 1. Run Server (Single-command fullstack)
```bash
# Starts Express server serving both REST API and React SPA on port 5001
node server/server.js
```
Open **[http://localhost:5001](http://localhost:5001)** in your browser!

### 2. Development Mode (Optional)
```bash
# In terminal 1 (Backend):
node server/server.js

# In terminal 2 (Vite Frontend):
cd client
npm run dev
```
Open **[http://localhost:5173](http://localhost:5173)** with hot-module reload.

### 3. Run Calculation Unit Tests
```bash
npm test
```
Verifies risk tiers, Rahul Verma's 8-class recovery formula, safe student bunk allowance, and Pearson correlation coefficient.

---

## 📡 Key REST API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/stats/overview` | Total students, avg attendance, critical/warning counts |
| `GET` | `/api/students` | All 30 students with computed metrics, search & filters |
| `GET` | `/api/students/:id` | Deep dive profile with subject breakdown and session logs |
| `GET` | `/api/subjects` | All 5 subjects with faculty names and average standing |
| `GET` | `/api/subjects/:id/roster` | Roster for a specific subject for rapid marking |
| `POST` | `/api/attendance/mark` | Record class session with bulk status array |
| `POST` | `/api/mentoring/log` | Record counseling intervention notes and action plan |
| `GET` | `/api/mentoring/logs` | Retrieve all mentoring cases |
| `POST` | `/api/alerts/send` | Simulate parent/student detention warning notice dispatch |
| `GET` | `/api/alerts/history` | View notification outbox audit trail |
| `POST` | `/api/medical/submit` | Submit medical certificate exemption application |
| `POST` | `/api/medical/:id/review` | Approve/reject medical leave; recalculates condonation |
| `GET` | `/api/analytics/correlation`| Midterm exam marks vs Attendance scatter plot dataset |
| `GET` | `/api/roster/export-csv` | Download complete attendance matrix CSV |
| `POST` | `/api/roster/import-csv` | Upload class roster CSV / biometric logs |
| `POST` | `/api/reset-seed` | Reset scenario to clean demo state |
